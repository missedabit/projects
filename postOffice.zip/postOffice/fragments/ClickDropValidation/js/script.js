$(document).ready( function(){


	$( ".tooltip" ).tooltip();
	$(".ui-helper-hidden-accessible").hide();

} )