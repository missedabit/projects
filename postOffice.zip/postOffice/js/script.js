$(document).ready( function(){

	$(".ui-helper-hidden-accessible").hide();

    $("#dropTable table tr").css("cursor","pointer").click( function(){
    	window.location.href = $(this).data('url');
    });

    $(".signContainer button").click( function(){
    	$(".signBox input").val("");
    	return false;
    } );

    $( "#label-message" ).dialog({
        autoOpen: false,
        modal: true,
        height: 250,
        width: 400,
        buttons: {
            Cancel: function() {
                $( this ).dialog( "close" );
            },  
            Print: function() {
                $( this ).dialog("close");
            }
         }
    });

    $(".ui-widget-overlay").click(function () {
    $(".ui-icon.ui-icon-closethick").trigger("click");
}); 

	$(".rejectLabel").click(function () {
	    $("#label-message").dialog('open');
	});

	$( "#weight-message" ).dialog({
		autoOpen: false,
		modal: true,
		buttons: {
			"Check Again": function() {
				$( this ).dialog( "close" );
			},	
			OK: function() {
				$( this ).dialog("close");
			}
		}
	});

	$(".weightLabel").click(function () {
	    $("#weight-message").dialog('open');
	}); 


} )


//Helper Functions

function getJsonTemplateForJSBridgeFunction()
{
	jsonObject = {
            "header": {
                "version": 1.0
            },
            "body": {
                "funcName": "",
                "funcParams": {},
                "callbackFuncName": "",
                "elementId" : ""
            }
        }
	return jsonObject;
}

var errorCodeEnum = { 
	"BridgeFuncNotAvailable": -1, 
	"Success": 0, 
	"DeviceConnectionError": 1,  
	"InvalidData": 2,
	"Unkonwn": 3
};

function showAlertViewIfNeeded(alertTitle,errorCode)
{
	//TODO: Alert view might need updating.
	var alertString = alertTitle;
	switch(errorCode)
	{
		case errorCodeEnum.BridgeFuncNotAvailable:
			alertString += ': Bridge function not available!';
			break;
		case errorCodeEnum.Success:
			//Do not show any alert message as succeeded.
			return;
		case errorCodeEnum.DeviceConnectionError:
			alertString += ': Device connection Error!';
			break;
		case errorCodeEnum.InvalidData:
			alertString += ': Invalid data used!';
			break;
		case errorCodeEnum.Unkonwn:
			alertString += ': Unknown error occured!';
			break;
	}
	alert(alertString);
}


var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() { //iOS or safari mac
        return navigator.userAgent.match(/iPhone|iPad|iPod/i) || navigator.userAgent.match(/AppleWebKit/);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};



function printSpecificPlatform(json)
{
    //alert("in printSpecificPlatform");
    if (isMobile.Android()) {
        javascriptBridge.printItem(json);
    }
    else if (isMobile.iOS())
    {
        printItem(json);
    }
    else if (isMobile.Windows())
    {
        window.external.notify(json);
    }
}

function weighSpecificPlatform(json)
{
    
    if (isMobile.Android()) {
        javascriptBridge.weigh(json);
    }
    else if (isMobile.iOS())
    {
        weigh(json);
    }
    else if (isMobile.Windows())
    {
        window.external.notify(json);
    }
}

function weighCancelSpecificPlatform()
{
	// get json template and populated with necessary information
	jsonObject = getJsonTemplateForJSBridgeFunction();
	jsonObject.body.funcName = "weighCancel";
	jsonString = JSON.stringify(jsonObject);
	
    if (isMobile.Android()) {
        javascriptBridge.weighCancel(jsonString);
    }
    else if (isMobile.iOS())
    {
        weigh(jsonString);
    }
    else if (isMobile.Windows())
    {
        window.external.notify(jsonString);
    }
}