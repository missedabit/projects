//Click & Drop Functions

var currentIndex = 0;
	function printLabels()
	{
		log("About to print labels")
		currentIndex = 0;
		enque(currentIndex)
	}
	

function doPrintingJob(htmlFileName, callbackFuncName)
	{
		// get json template and polulated with necessary information
		jsonObject = getJsonTemplateForJSBridgeFunction();
		jsonObject.body.funcName = "printItem";
		jsonObject.body.callbackFuncName = callbackFuncName;
		jsonObject.body.funcParams["htmlName"] = htmlFileName;
		jsonString = JSON.stringify(jsonObject);
        
		try {
			//printItem(jsonString);
		    //printSpecificPlatform(jsonString);
		    window.external.notify(jsonString);
		} catch(e) {
			var fn = window[callbackFuncName];
			if(typeof fn === "function") fn(errorCodeEnum.BridgeFuncNotAvailable);
		}
	}

	function printCOPCallback(errorCode)
	{
		showAlertViewIfNeeded("Printing COP", errorCode);
        if(errorCode == errorCodeEnum.Success) {
			// Printing COP succeeded. so print next item, receipt.
            //doPrintingJob("postAParcel_receipt", "printReceiptCallback");
        }
	}

    function printReceiptCallback(errorCode)
    {
    	showAlertViewIfNeeded("Printing Receipt", errorCode);
    }

	function enque(index)
	{
		log("enque: " + index + " of " + purchase.lineItems.length)
		if (index >= purchase.lineItems.length)
		{
			// Printing All labels succeeded. so print next item, COP.
			doPrintingJob("printableCop", "printCOPCallback");
			return;
		}
		
		var lineItem = new LineItem();
		var service = new Service()
		extend(lineItem, purchase.lineItems[index]);
		extend(service, purchase.lineItems[index].service)

		//set a session value.
		setValueForKey(lineItem, "label.print.lineItem");
		setValueForKey(service, "label.print.service");
		
		if (lineItem.included)
		{
			printLabel(lineItem, service);
		} else {
			currentIndex = ++index;
			enque(currentIndex);
		}
	}
	
	function printLabel(lineItem, service)
	{
		doPrintingJob("printableLabel", "printLabelCallback");
	}
	
	function printLabelCallback(errorCode)
	{
		showAlertViewIfNeeded("Printing Label",errorCode);
		if(errorCode == errorCodeEnum.Success) {
			enque(++currentIndex);			
		}
	}


