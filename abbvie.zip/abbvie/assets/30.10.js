slide["30.10"] = {
    "id": "page_30_10",
    "tpl": "small",
    "header": "Therapie- Und PAtIentenMAnAgeMent geMeInsAM gestAlten: UnseRe foRt- BIldUngsAngeBote fÜR sIe Und IHR TEAM",
    child: [
        {
            tpl: "_text.list",
            text: [
				'CURRICULUM',
				'IBD HEAD',
				'CED FACHASSISTENZ',
				'BIO-LOGICUM',
				'COMPLIANCE-KOLLEG',
				'CED REGIONALVERANSTALTUNGEN'
			]
        },
    ],
    "navigation": [
        { "slide": "30.00" },
        { "class": "active" },
		 { "slide": "30.20"}
    ]                   
};