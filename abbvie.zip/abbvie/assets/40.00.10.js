slide["40.00.10"] = {
    "id": "page_40_00_10",
    "tpl": "single.graph",
    "header": "HUMIRA® - MORBUS CROHN-PATIENTEN PROFITIEREN VOM FRÜHEN EINSATZ<sup>12</sup>", 
	"text": "Doppelt so viele Patienten mit kurzer Erkrankungsdauer erreichten unter kontinuierlicher HUMIRA®-Therapie nach 12 Wochen eine Mukosaheilung",
	"disclaimer": [
		"&nbsp;&nbsp;&nbsp;12&nbsp;&nbsp;&nbsp; Sandborn WJ, et al. Gastroenterology; 38 (5 Suppl 1): S-164/DDW2010; S1031"
	], 
	"div": [
		  { "class": "graph-bottom-text_1", "name": "HUMIRA® Induktionstherapie/Placebo" },
		  { "class": "graph-bottom-text_2", "name": "Kontinuierlich HUMIRA®" },
		  { "class": "vertical-txt", "name": "Patienten mit Mukosaheilung (%)" }
	],
	"graphImg": "40-1",
	"identText": [
            "NRI-Analyse; N=123 Patienten mit Ulzerationen<br>zur Baseline-Visite",
             "p &lt; 0,029 (Breslow-Day-Test) für den Unterschied<br>bzgl. Patienten mit einer Crohn-Erkrankung &lt; 5 Jahren<br>vs. 5 Jahren."
        ],
	"button": "ZUR STUDIE",
	"popup": "40.00_1|popup-in",
	
    "navigation": [
        { "slide": "40.00" },
        {  "class": "active"  }
    ] 	
};
	
	
	

