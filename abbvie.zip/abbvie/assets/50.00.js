slide["50.00"] = {
    "id": "page_50_00",
    "tpl": "product",  
	text: [
		"Patienten profitieren vom<br/>Fr&Uuml;hzeitigen Einsatz<sup>12</sup>",
		"Wirkt schnell und anhaltend<sup>1,2,4</sup>",
		"Remissionserhalt bis zu 4 Jahre<br/>in Studien nachgewiesen<sup>1,4</sup>",
		"Langj&auml;hrige Erfahrung und<br/>gr&ouml;SSte, ver&ouml;ffentlichte<br/>Anti-TNF-Sicherheitsdatenbank<sup>7</sup>",
		"Der einzige Pen f&uuml;r Morbus<br/>Crohn und Colitis Ulcerosa<sup>1</sup>"
	],
	paratext: [
		"1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fachinformation HUMIRA<sup>®</sup> 40 mg Injektionsl&ouml;sung im vorgef&uuml;llten Pen, Stand September 2013",
		"2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hanauer S, et al. Gastroenterology 2006; 130: 323-333",
		"4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247",
		"7&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Burmester G, et al.Ann Rheum Dis 2013;72:517-524",
		"12&nbsp;&nbsp;&nbsp;Sandborn WJ, et al.Gastroenterology; 38(5 Suppl1):S-164 / DDW2010;S1031"
	]               
};
