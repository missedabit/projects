slide["30.00"] = {
    "id": "page_30_00",
    "tpl": "small",
    "header": "VERTRAUEN Sie HUMIRA<sup>&reg;</sup>",
    child: [
        {
            tpl: "_big.nr",
            nr: 71,
            text: 'klinische <span class="ucase">S</span>tudien in der gr&ouml;&#223;ten ver&ouml;ffentlichten<br />Anti-TNF-Sicherheitsdatenbank<sup>7</sup>'
        },
		
        {
            tpl: "_big.nr",
            nr:16,
            text: 'Jahre Erfahrung aus klinischen Studien<sup>9</sup>'
        },
		
        {
            tpl: "_big.nr",
            nr:9,
            text: 'Indikationen inkl. Morbus<br>Crohn und Colitis ulcerosa<sup>1</sup>'
        },
				
        {
            tpl: "text.box",
            text: [ 
				'<span class="text-right"><span class="uber-text">IN ÜBER</span> <span class="sackersgothicstdlight size28">89</span><br>Ländern Zugelassen<sup>14</sup></span>'
            ]
        },
						
        {
            tpl: "text.box",
            text: [ 
				'<span class="mehral-text">MEHR ALS</span> <span class="sackersgothicstdlight size25">740.000</span><br>aktuell weltweit behandelte<br>Patienten<sup>14</sup>' ]
        },
		
        {
            tpl: "text.box",
            text: [ 
				'<span class="text-last"><span class="mehral-text">	MEHR ALS</span> <span class="sackersgothicstdlight size25">40.000</span><span class="humira-text">HUMIRA<sup>®</sup>- Patienten in Deutschland<sup>18</sup></span></span>' ]
        },
		

    ],
    "navigation": [
        { "class": "active" },
        { "slide": "30.10"},
		{ "slide": "30.20"}
    ]                   
};