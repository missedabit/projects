slide["60.00"] = {
    "id": "page_60_00",
    "tpl": "home",
	button:false,
    "header": "HUMIRA<sup>&reg;</sup> &ndash; Zwei Indikationen, Ein Weg",
    "subHeader": "Zur Behandlung des mittelschweren bis schweren, aktiven Morbus Crohn (MC)<br />bei erwachsenen Patienten<sup>1</sup>",
    "disclaimer": "1&nbsp;&nbsp;&nbsp;HUMIRA&reg; - Fachinformation, Stand September 2013.",
	"menu": [
		{ "slide": "60.10", "name": "ABBVIE CARE" },
		{ "slide": "60.10.10", "name": "Leitlinien" },
		{ "slide": "60.30.10", "name": "Sicherheit" },
		{ "slide": "60.10", "name": "Dosierung" },
		{ "slide": "60.10", "name": "Praxisbesonderheit"}
	]               
};