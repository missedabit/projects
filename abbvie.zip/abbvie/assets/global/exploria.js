//Nav Object
var nav = {
//----<Configuration>----\\
config: {
//Local slide navigation; Set false for use in exploria. If left true it will not affect slide linking in exploria
local: true,
//Set the relative folder path to your pdf files
pdfLocation: 'pdf/',
},

//----</Configuration>----\\
//----<GUIDS>----\\
//Slide names and GUIDs
slides: {
'00.00': '799e9172-9ad7-411c-acd7-75d1cdca036c',
'00.00.10': '6b360ce2-20a9-455a-88a8-43a71445014e',
'10.00': '462b47d7-395e-485d-825d-c644e4aac465',
'10.10': '9d442f32-3369-481e-9d01-46305c533e54',
'10.10.10': '68a36f89-236c-457b-a114-1e3e7496560e',
'10.20': '0bcb1c4c-fa08-4f0f-b04f-67ff9a8d459a',
'10.20.10': '580c3b6b-4e08-4038-a554-0ccebbfd5b98',
'10.20.20': '9733a58d-264a-4ca9-b525-ac8254603f2a',
'10.20.30': '9115b9c1-6f1a-49b8-b8b2-3d2959d0fe83',
'20.00': '7f24818e-e35a-4807-bb60-6c86b25ebe45',
'20.00.20': '8b8d0ae1-df02-4b55-9f81-0d8a9d99b16f',
'20.00.30': 'f64fba21-8bc2-4a75-a75b-88b9b0e1e35a',
'20.00.40': '950b8cac-62f1-4627-a5c9-e44514b1ab2c',
'20.00.50': '2114ef31-cd24-4e91-9449-a52dbd0d6cd2',
'30.00': '88960b0d-42b7-4e84-84ff-ca7fb7e3c933',
'30.00.10': '7c0d21f0-3040-4841-b91b-904c5d9222a4',
'30.00.20': '967b72c4-1f86-4ec6-bc1d-f4096393722c',
'30.00.30': '761060ba-a4df-47f6-adeb-649f0876edd7',
'40.00': 'a6be432e-5344-4b5d-b3b7-55786b6358de',
'40.10': '5334cfc5-b70e-48c3-90ab-11619c8c80eb',
'50.00': '3ea5d2ab-7484-4c34-8a34-74a9f6bf4e42',
'50.10': 'c40f64d7-4c85-43b2-a113-503824fd0bda',
'50.10.10': '0f5bc7f0-dad3-4e3d-bc3e-8082c6909339',
'50.10.20': 'd59e2223-18ba-42af-9db2-78ea4abd163c',
'50.20': 'ce69ea34-218b-4243-a46e-231c8864d570',
'50.20.10': '83d07e0b-54c9-462b-b497-3d710ae64690',
'50.20.20': 'a875a92f-bbf5-41e7-9a95-b43c15b54533',
'50.20.30': '73839e2e-6e00-417a-bbea-d340146acba1',
'50.20.40': '4038d60f-e6b3-4701-87dd-9d8c5997b154',
'50.30': 'ae7cc1e1-7bf1-4a43-82f4-fff837ab26b2',
'50.30.10': '451ad059-22be-47f0-b9f1-53206b307174',
'50.30.20': '164402b3-bc3d-4e1f-a8fe-69430223abb0',
'50.40': 'bd13be99-f93a-42cc-9803-76d5ab6e5f70',
'50.50': 'b70f3fba-6a3d-4c92-8808-ac1148195110',
'50.50.10': '2dfd45c9-1216-4414-9f87-7b8165c7db78'
},
//Reprint names and Guids
reprints: {
'fachinfo': '5af302c4-b66f-469c-ae70-25e99a25c1b5',
'referenzen': '07e79e48-5783-4920-b14f-6d1d53e8a93c',
},
//----</GUIDS>----\\
//----<Navigation>----\\
//use this function to navigate to an HTML slide locally and in Exploria
navSlide: function (fileName) {
	trackFeedback();
//Navigate to slide guid when inside exploria
	goToSlide(nav.slides[fileName]);
//If local is set true navigate to the html file
	// if (nav.config.local) {
	// 	document.location = fileName + '.html';
	// }
},
//use this function to navigate to a reprint locally and in Exploria navReprint: function (fileName) {
//----</Navigation>----\\

navReprint: function (fileName) {
//Navigate to reprint guid when inside exploria
goToSlide(nav.reprints[fileName]);
if (nav.config.local) {
document.location = nav.config.pdfLocation + fileName + '.pdf';
}
//----</Navigation>----\\
}

}
ESP.GetAccessSlideIds = function () 
{
    return [
			nav.slides['00.00'], 
			nav.slides['00.00.10'], 
			nav.slides['10.00'], 
			nav.slides['10.10'], 
			nav.slides['10.10.10'], 
			nav.slides['10.20'], 
			nav.slides['10.20.10'], 
			nav.slides['10.20.20'], 
			nav.slides['10.20.30'], 
			nav.slides['20.00'], 
			nav.slides['20.00.20'], 
			nav.slides['20.00.30'], 
			nav.slides['20.00.40'], 
			nav.slides['20.00.50'], 
			nav.slides['30.00'], 
			nav.slides['30.00.10'], 
			nav.slides['30.00.20'], 
			nav.slides['30.00.30'], 
			nav.slides['40.00'], 
			nav.slides['40.10'], 
			nav.slides['50.00'], 
			nav.slides['50.10'], 
			nav.slides['50.10.10'], 
			nav.slides['50.10.20'], 
			nav.slides['50.20'], 
			nav.slides['50.20.10'], 
			nav.slides['50.20.20'], 
			nav.slides['50.20.30'], 
			nav.slides['50.20.40'], 
			nav.slides['50.30'], 
			nav.slides['50.30.10'], 
			nav.slides['50.30.20'], 
			nav.slides['50.40'], 
			nav.slides['50.50'], 
			nav.slides['50.50.10'], 
			nav.reprints['fachinfo'],
			nav.reprints['referenzen'],
		];
}
//Access Rule 
