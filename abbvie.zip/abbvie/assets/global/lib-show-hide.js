Array.prototype.last = function() {return this[this.length-1];}

var lib_showHide = function() {
    $('[show]').bind(tarEvent, function (event) {
        var $btn = $(this),
            tab = $btn.attr('show'),
            $btns = $('[show="'+tab+'"]'),
            $tab = $('[tab="'+tab+'"]'),
            id = tab;

        $btns.addClass('show-active');
        $tab.show();

        if (id) 
            if (config[id]) {
                actions.updateSlideId(id);
                if (config[id].type) 
                    if (slideLog) {
                        var type = config[id].type.toLowerCase();
                        if (typeof slideLog[type] == 'function')
                            slideLog[type](id);
                    }
            }
    });

    $('[hide]').bind(tarEvent, function(event) {
        var $btn = $(this),
            tab = $btn.attr('hide'),
            $btns = $('[hide="'+tab+']'),
            $tab = $('[tab="'+tab+'"]');

        $btns.removeClass('show-active');
        $tab.hide();
    });

    $('[toggle]').bind(tarEvent, function(event) {
        var $btn = $(this),
            tab = $btn.attr('toggle'),
            $tab = $('[tab="'+tab+'"]');

        $btn.toggleClass('show-active');

        $tab.toggle();
    });

    var showOnly = function(event, that, tab) {
        console.log(tab);
        event.stopPropagation();
        var redirect = tab.split(':');
        var type;
        var id = redirect.last() 
        if (!config)
            var config = {};
        if (id) {
            if (config[id]) {
                actions.updateSlideId(id);
                if (config[id].type)
                    type = config[id].type.toLowerCase();
                    if (slideLog)
                        if (typeof slideLog[type] == 'function') {
            }
//                            slideLog[config[id].type](id);
                        }
        };

        if (redirect.length == 2) {
            if (type && type != 'page')
                slideLog[type](id);

            window.location.href = redirect[1]+".html";
            return;
        };

        if (type) {
            slideLog[type](id);
        }

        var group,
            allTabs,
            $allTabs;

        var $btn = $(that),
            tab = (tab) ? tab:$btn.attr('show-only'),
            $btns = $('[show-only="'+tab+'"]'),
            $btns2 = $('[show="'+tab+'"]'),
            $tab = $('[tab="'+tab+'"]'),
            $btnGroup = $btn.closest('[tab-group]');

        group = $btnGroup.attr('tab-group');
        if (group) {            
            allTabs = '[tab-group="'+group+'"] [tab]';
        } else
            allTabs = '[tab]:not([tab-group] [tab])';

        $allTabs = $(allTabs);
        console.log(group, allTabs, $btnGroup);


        $('.show-active').removeClass('show-active');
        $btns.addClass('show-active');
        $btns2.addClass('show-active');
        $allTabs.hide();
        $tab.show();
    }

    $('[show-only]').bind(tarEvent, function (event)
    {
        console.log($(this).attr('show-only'));
        showOnly(event, this, $(this).attr('show-only'));
    });

    $('[swipe-left]').bind('swipeleft', function(event) {
        showOnly(event, this, $(this).attr('swipe-left'));
    });

    $('[swipe-right]').bind('swiperight', function(event) {
        showOnly(event, this, $(this).attr('swipe-right'));
    });

    // $('article').bind('swipeleft', function(event) {
    //     console.log('next', slideId);
    // });
}


$(document).ready(function(){
    lib_showHide(); 
});