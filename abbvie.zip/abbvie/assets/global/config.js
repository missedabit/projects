var slide = {};
var config = {
    "00.00": {
        "00.00.10": {
            trackId: "PG_Product_go00.00.10Btn",
            keywords: "Button, go to Menue",
            type: "button"
        },
        "id": "page_00_00",
        "tpl": "home",
        "header": "HUMIRA<sup>&reg;</sup> &ndash; Zwei Indikationen, Ein Weg",
        "subHeader": "Zur Behandlung des mittelschweren bis schweren, aktiven Morbus Crohn (MC)<br />bei erwachsenen Patienten<sup>1</sup>",
        "disclaimer": "1&nbsp;&nbsp;&nbsp;HUMIRA&reg; - Fachinformation, Stand September 2013.",
        "button": true    
    },
    "00.00.10": {
        "20.00": {
            trackId: "PG_Homewithlinks_go10.00Btn",
            keywords: "Button, go to WIRKSAMKEIT",
            type: "button"            
        },
        "extend": "00.00",
        "id": "page_00_00_10",
        "button": false,
        "menu": [
            { "slide": "20.00", "name": "LEITLINIEN" },
            { "slide": "20.00", "name": "WIRKSAMKEIT" },
            { "slide": "30.00", "name": "PATIENT" },
            { "slide": "40.00", "name": "MUKOSAHEILUNG" },
            { "slide": "60.00", "name": "BACKUP"}
        ]
    },
    "20.00": {
        "20.00.10": {
            trackId: "SL_Rapid_go10.10btn",
            keywords: "Button, go to Schnell",
            message: "Home",
            type: "Button"
        },
        "20.10": {
            trackId: "SL_Sustained_go10.20",
            keywords: "Button, go to Anhaltend",
            message: "Home",
            type: "Button"
        },
    },
    "20.00.10": {
        trackId: "PG_QoL",
        keywords: "Page,QoL",
        message: "Schnell, stark und anhaltend",
        type: "Page",
        "20.00.10_1": {
            trackId: "SL_Classic1",
            keywords: "Pop-up, Classic1",
            message: "Classic 1",
            type: "PopUp"
        },
        "id": "page_20_00_10",
        "tpl": "single.graph",
        "header": "HUMIRA<sup class='novelsansrdproextralight size10'>&reg;</sup> &ndash; SIGNIFIKANTE VERBESSERUNG DER LEBENS-<br/> QUALIT&Auml;T NACH DER ERSTEN GABE<sup class='novelsansrdproextralight size10'>#,2</sup>",
        "button": "ZUR STUDIE",
        "popup": "20.00.10_1|popup-in",
        "graphImg": "10-1",
        "identText": [
            "&dagger;&nbsp;&nbsp;&nbsp;&nbsp; p&lt;0,05 ADA 160/80 mg und ADA 80/40 mg<br/> vs. Placebo",
            "*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; p&lt;0,05 ADA 160/80 mg vs. Placebo",
            "#&nbsp;&nbsp;&nbsp;&nbsp; Gemessen mit dem Inflammatory Bowel <br/>Disease Questionnaire-(IBDQ)",
            "ADA= Adalimumab"
        ],
        "text": "Mit HUMIRA<sup>&reg;</sup> zur&uuml;ck im Leben<sup>#</sup>- <br/> mit der 160 mg-Dosierung bereits nach einer Woche",
        "disclaimer": "2&nbsp;&nbsp;&nbsp; Hanauer S, et al. Gastroenterology 2006; 130: 323-333",
        "div": [
              { "class": "graph-bottom-text_1", "name": "Placebo" },
              { "class": "graph-bottom-text_2", "name": "ADA 40/20 mg" },
              { "class": "graph-bottom-text_3", "name": "ADA 80/40 mg" },
              { "class": "graph-bottom-text_4", "name": "ADA 160/80 mg" },
              { "class": "x-axis1", "name": "160" },
              { "class": "x-axis2", "name": "155" },
              { "class": "x-axis3", "name": "150" },
              { "class": "x-axis4", "name": "145" },
              { "class": "x-axis5", "name": "140" },
              { "class": "x-axis6", "name": "135" },
              { "class": "x-axis7", "name": "130" },
              { "class": "x-axis8", "name": "125" },
              { "class": "x-axis9", "name": "120" },
              { "class": "yaxis-1", "name": "Woche" },
              { "class": "yaxis-2", "name": "Woche" },
              { "class": "yaxis-3", "name": "Woche" },
              { "class": "yaxis-4", "name": "Woche" },
              { "class": "yaxis-5", "name": "Woche" },
              { "class": "yaxis-11", "name": "0" },
              { "class": "yaxis-21", "name": "1" },
              { "class": "yaxis-31", "name": "2" },
              { "class": "yaxis-41", "name": "3" },
              { "class": "yaxis-51", "name": "4" },
              { "class": "symbol1", "name": "*" },
              { "class": "symbol2", "name": "†" },
              { "class": "symbol3", "name": "†" },
              { "class": "vertical-txt", "name": "Mittlerer IBDQ-Wert (Punkte)" }
        ],
        "slider": {
            "position": "right",
            "slide": "20.10|movenext",
            "name": "ANHALTEND"
        },
        "navigation": [
            { "class": "active" },
            { "slide": "20.00.20"}
        ]           
    },
    "20.00.10_1": {
        "tpl": "popup",
        "slideName": "20.00.10",
        "header": "STUDIENDESIGN",
        "title": "CLASSIC-1<sup>2</sup>",
        "disclaimer": "2&nbsp;&nbsp;&nbsp; Hanauer S, et al. Gastroenterology 2006; 130: 323-333",
        "text": [
            "Randomisierte, placebokontrollierte, multizentrische, doppelblinde<br />Phase-III-Studie &uuml;ber 4 Wochen mit Biologika-naiven Patienten mit<br />mittelschwerem bis schwerem, aktivem Morbus Crohn (n = 299) zur Remissionsinduktion",
            "Prim&auml;rer Endpunkt: &nbsp;Klin. Remission in Woche 4 (HUMIRA<sup>&reg;</sup> 160/80 mg<br />oder 80/40 mg vs. Placebo); sekund&auml;re Endpunkte u.a.: klin. Ansprechen,<br />Verbesserung des IBDQ",
            "Bei 160/80 mg 36 % der Patienten in Remission, bei 80/40mg 24%<br />(Placebo: 12 %); bei 160/80 mg signifikante IBDQ-Verbesserung<br />bereits nach 1 Woche im Vergleich zu Placebo",
            "Anzahl unerw&uuml;nschter Ereignisse war unter HUMIRA<sup>&reg;</sup><br />und Placebo vergleichbar"
        ],
        "back": "20.00.10|popup-out",
        "slider": {
            "position": "right",
            "slide": "20.10|movenext",
            "name": "ANHALTEND"
        }           
    },
    "20.00.20": {
        trackId: "PG_Sustained_Remission",
        keywords: "Page, Sustained Remission",
        message: "Schnell, stark und anhaltend",
        type: "Page",        
        "20.00.20_1": {
            trackId: "SL_Charm/Adhere",
            keywords: "Pop-Up, Charm/Adhere",
            message: "Charm/Adhere",
            type: "PopUp"            
        },
        "id": "page_20_00_20",
        "tpl": "single.graph",
        "header": "HUMIRA<sup>&reg;</sup> &ndash; SCHNEll WIRKSAM<sup>2</sup>",
        "button": "ZUR STUDIE",
        "popup": "20.00.20_1|popup-in",
        "graphImg": "10-2",
        "paragraphText": "Die Analyse beinhaltet die 2 h&ouml;heren HUMIRA<sup>&reg;</sup><br />Dosierungen vs. Kontrollgruppe unter Verwendung der<br />Non-Responder Imputation (NRI-Analyse). <br />Patienten mit unvollst&auml;ndigen Daten wurden als nicht in <br />klinischer Remission befindlich eingestuft",
        "identText": [
            "*&nbsp;&nbsp;&nbsp;&nbsp; Definition von klinischer Remission: <br />Crohn's disease activity index &lt; 150 Punkte",
            "a&nbsp;&nbsp;&nbsp;&nbsp; p&lt;0,001 HUMIRA<sup>&reg;</sup> 160 mg/80 mg gegen&uuml;ber Kontrollgruppe"
        ],
        "text": "Erleichterung f&uuml;r ihre<br />Patienten durch schnelle<br />klinische Remission mit HUMIRA<sup>&reg;</sup>",
        "disclaimer": "2&nbsp;&nbsp;&nbsp; Hanauer S, et al. Gastroenterology 2006; 130: 323-333",
        "slider": {
            "position": "right",
            "slide": "20.10|movenext",
            "name": "ANHALTEND"
        },
        "navigation": [
            { "slide": "20.00.10"},
            { "class": "active" }
        ]                   
    },
    "20.00.20_1": {
        "tpl": "popup",
        "title": "CLASSIC-1<sup>2</sup>",
        "text": [
            "Randomisierte, placebokontrollierte, multizentrische, doppelblinde<br />Phase-III-Studie &uuml;ber 4 Wochen mit Biologika-naiven Patienten mit<br />mittelschwerem bis schwerem, aktivem Morbus Crohn (n = 299) zur Remissionsinduktion",
            "Prim&auml;rer Endpunkt: &nbsp;Klin. Remission in Woche 4 (HUMIRA<sup>&reg;</sup> 160/80 mg<br />oder 80/40 mg vs. Placebo); sekund&auml;re Endpunkte u.a.: klin. Ansprechen,<br />Verbesserung des IBDQ",
            "Bei 160/80 mg 36 % der Patienten in Remission, bei 80/40mg 24%<br />(Placebo: 12 %); bei 160/80 mg signifikante IBDQ-Verbesserung<br />bereits nach 1 Woche im Vergl. zu Placebo",
            "Anzahl unerw&uuml;nschter Ereignisse war unter HUMIRA<sup>&reg;</sup><br />und Placebo vergleichbar"
        ],
        "disclaimer": "2&nbsp;&nbsp;&nbsp;&nbsp; Hanauer S, et al. Gastroenterology 2006; 130: 323-333",
        "back": "20.00.20|popup-out",
        "slider": {
            "position": "right",
            "slide": "20.10|movenext",
            "name": "ANHALTEND"
        }           
    },
    "20.10": {
        trackId: "PG_Sustained_Remission",
        keywords: "Page, Sustained Remission",
        message: "Schnell, stark und anhaltend",
        type: "Page",
        "id": "page_20_10",
        "tpl": "single.graph",
        "header": "HUMIRA<sup>&reg;</sup> - ANHALTENDE REMISSION BIS ZU 4 JAHRE NACHGEWIESEN<sup>3</sup>",
        "button": "ZUR STUDIE",
        "popup": "20.10_1|popup-in",
        "graphImg": "10-3",
        "identText": [
            "**&nbsp;&nbsp; CHARM-Studie<sup>3</sup>",
            "*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bezieht sich auf HUMIRA<sup>&reg;</sup>-randomisierte Patien-<br />ten mit Therapieansprechen, die zur Woche 56 der<br />CHARM-Studie<sup>4</sup> in Remission waren und an der Ver-<br />l&auml;ngerungsstudie ADHERE<sup>5</sup> teilnehmen (ITT, n= 145);<br />LOCF<sup>17</sup>= Last-observation-carried-forward-Analyse."
        ],
        "text": "80% der Patienten sind nach dem<br />4. Jahr mit HUMIRA<sup>&reg;</sup> weiterhin<br />in klinischer Remission<sup>#</sup>",
        "disclaimer": [
            "3&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247",
            "4&nbsp;&nbsp;&nbsp;&nbsp; Colombel JF, et al. Gastroenterology 2007; 132: 52-65",
            "5&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2010; 31: 1296-309"
        ],        
        "slider": {
            "position": "left",
            "slide": "20.00.10|moveprev",
            "name": "SCHNELL"
        },
        "navigation": [
            { "class": "active" },
            { "slide": "20.10.10"}
        ]           
    },
    "20.10_1": {
        trackId: "SL_Charm",
        keywords: "Pop-up, Charm",
        message: "Charm",
        type: "PopUp",            
        "tpl": "popup",
        "buttons": [
            {"name": "CHARM STUDIENDESIGN<sup>4</sup>", "class":"show-active"},
            {"slide":"20.10_2", "name": "ADHERE OLE STUDIENDESIGN<sup>5</sup>"}
        ],
        "title": "CHARM<sup>4</sup>",
        "text": [
            "Multizentrische, randomisierte, doppelt verblindete und<br />placebokontrollierte Phase-III-Studie &uuml;ber 56 Wochen<br />mit 4-w&ouml;chiger offenen Induktionsphase und mit ADHERE<sup>5</sup><br />als offener Anschlußstudie (Woche 56–212)",
            "Anti-TNF-naive und mit Infliximab vorbehandelte Patienten<br />mit mittelschwerem bis schwerem, aktivem Morbus Crohn (n = 854)",
            "Prim&auml;rer Endpunkt: Klin. Remission der randomisierten Responder<br />zur Woche 26 und 56; sek. Endpunkte: u.a. klin. Ansprechen (CR-70 u. CR-100)",
            "36 % bzw. 41 % der randomisierten Ansprecher unter<br />HUMIRA<sup>&reg;</sup> zur Wo. 56 in Remission vs. 17 % bei Placebo<br />(zur Wo. 26 40 % und 47 % vs. 12 % bei Placebo)."
        ],
        "disclaimer": [
            "4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Colombel JF, et al. Gastroenterology 2007; 132: 52-65",
            "5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247"
        ],
        "back": "20.10|popup-out",
        "slider": {
            "position": "left",
            "slide": "20.00.10|moveprev",
            "name": "SCHNELL"
        }   
    },
    "20.10_2": {
        trackId: "SL_Adhere",
        keywords: "Pop-up, Adhere",
        message: "Adhere",
        type: "PopUp",
        "tpl": "popup",
        "buttons": [
            {"slide":"20.10_1", "name": "CHARM STUDIENDESIGN<sup>4</sup>"},
            {"name": "ADHERE OLE STUDIENDESIGN<sup>5</sup>", "class":"show-active"}
        ],
        "title": "ADHERE<sup>5</sup>",
        "text": [
            "Offene Studie zum Langzeitremissionserhalt und zur Langzeitsicherheit<br />&uuml;ber bis zu 3 Jahre mit Patienten, die bis zum Ende an den Studien<br />CHARM oder GAIN teilgenommen hatten",
            "Analyse von 329 HUMIRA<sup>&reg;</sup>-randomisierten Patienten mit<br />Therapieansprechen zur Woche 4",
            "Studienendpunkte u. a.: klinische Remission sowie steroidfreie Remission<br />&uuml;ber 4 Jahre HUMIRA<sup>&reg;</sup>-Behandlung",
            "80 % (LOCF) bzw. 53,8 % (NRI) der Patienten mit Therapieansprechen,<br />die sich am Ende von CHARM in Remission befanden, waren nach 3 weiteren<br />Jahren unter Adalimumab weiterhin in Remission"
        ],
        "disclaimer": [
            "4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Colombel JF, et al. Gastroenterology 2007; 132: 52-65",
            "5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247"
        ],
        "back": "20.10|popup-out",
        "slider": {
            "position": "left",
            "slide": "20.00.10|moveprev",
            "name": "SCHNELL"
        }   

    },
    "20.10.10": {
        trackId: "PG_Sustained_Remission(2)",
        keywords: "Page, Sustained Remission(2)",
        message: "Schnell, stark und anhaltend",
        type: "Page",
        "id": "page_20_10_10",
        "tpl": "single.graph",
        "header": "HUMIRA<sup>&reg;</sup> - NACHGEWIESEN ANHALTENDE REMISSION<sup>3</sup>",
        "button": "ZUR STUDIE",
        "popup": "20.10.10_1|popup-in",
        "graphImg": "10-4",
        "title": "Mittlerer Crohn’s disease activity Index (CDAI)<br />&uuml;ber die Zeit",
        "paragraphText": [
            "*&nbsp;&nbsp; CHARM-Studie<sup>4</sup>",
            "Gestrichelte Linie repr&auml;sentiert das Erreichen der Schwelle zur klinischen Remission (CDAI &lt; 150)"
        ],
        "text": "Anhaltende Erleichterung f&uuml;r<br />Ihre Patienten - schnelle und<br />kontinuierliche Verbesserung<br />des mittleren CDAI",
        "disclaimer": [
            "3&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247",
            "4&nbsp;&nbsp;&nbsp;&nbsp; Colombel JF, et al. Gastroenterology 2007; 132: 52-65"
        ],        
        "slider": {
            "position": "left",
            "slide": "20.00.10|moveprev",
            "name": "SCHNELL"
        },
        "navigation": [
            { "slide": "20.10"},
            { "class": "active" }
        ]        

    },
    "20.10.10_1": {        
        trackId: "SL_Charm_Studiendesign",
        keywords: "Pop-Up, Charm Studiendesign",
        message: "Charm Studiendesign",
        type: "PopUp",
        "tpl": "popup",
        "buttons": [
            {"name": "CHARM STUDIENDESIGN<sup>4</sup>", "class":"show-active"},
            {"slide":"20.10.10_2", "name": "ADHERE OLE STUDIENDESIGN<sup>5</sup>"}
        ],
        "title": "CHARM<sup>4</sup>",
        "text": [
            "Multizentrische, randomisierte, doppelt verblindete und<br />placebokontrollierte Phase-III-Studie &uuml;ber 56 Wochen<br />mit 4-w&ouml;chiger offenen Induktionsphase und mit ADHERE<sup>5</sup><br />als offener Anschlußstudie (Woche 56–212)",
            "Anti-TNF-naive und mit Infliximab vorbehandelte Patienten<br />mit mittelschwerem bis schwerem, aktivem Morbus Crohn (n = 854)",
            "Prim&auml;rer Endpunkt: Klin. Remission der randomisierten Responder<br />zur Woche 26 und 56; sek. Endpunkte: u.a. klin. Ansprechen (CR-70 u. CR-100)",
            "36 % bzw. 41 % der randomisierten Ansprecher unter<br />HUMIRA<sup>&reg;</sup> zur Wo. 56 in Remission vs. 17 % bei Placebo<br />(zur Wo. 26 40 % und 47 % vs. 12 % bei Placebo)."
        ],
        "disclaimer": [
            "4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Colombel JF, et al. Gastroenterology 2007; 132: 52-65",
            "5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247"
        ],
        "back": "20.10.10|popup-out",
        "slider": {
            "position": "left",
            "slide": "20.00.10|moveprev",
            "name": "SCHNELL"
        }           
    },
    "20.10.10_2": {
        tpl: "popup",
        trackId: "SL_Charm/Adhere",
        keywords: "Pop-Up, Charm/Adhere",
        message: "Charm/Adhere",
        type: "PopUp",
        "buttons": [
            {"slide":"20.10.10_1", "name": "CHARM STUDIENDESIGN<sup>4</sup>"},
            {"name": "ADHERE OLE STUDIENDESIGN<sup>5</sup>", "class":"show-active"}
        ],
        "title": "ADHERE<sup>5</sup>",
        "text": [
            "Offene Studie zum Langzeitremissionserhalt und zur Langzeitsicherheit<br />&uuml;ber bis zu 3 Jahre mit Patienten, die bis zum Ende an den Studien<br />CHARM oder GAIN teilgenommen hatten",
            "Analyse von 329 HUMIRA<sup>&reg;</sup>-randomisierten Patienten mit<br />Therapieansprechen zur Woche 4",
            "Studienendpunkte u. a.: klinische Remission sowie steroidfreie Remission<br />&uuml;ber 4 Jahre HUMIRA<sup>&reg;</sup>-Behandlung",
            "80 % (LOCF) bzw. 53,8 % (NRI) der Patienten mit Therapieansprechen,<br />die sich am Ende von CHARM in Remission befanden, waren nach 3 weiteren<br />Jahren unter Adalimumab weiterhin in Remission"
        ],
        "disclaimer": [
            "4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Colombel JF, et al. Gastroenterology 2007; 132: 52-65",
            "5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-1247"
        ],
        "back": "20.10.10|popup-out",
        "slider": {
            "position": "left",
            "slide": "20.00.10|moveprev",
            "name": "SCHNELL"
        }        
    },
    "30.00": {
        "one": { 
            trackId: "SL_Charm/Adhere",
            keywords: "Pop-Up, Charm/Adhere",
            message: "Charm/Adhere",
            type: "PopUp"        
        }
    }
}

//-------------------------------------------------------------------------
//  use this link to escape templates
// http://bernhardhaeussner.de/odd/json-escape/#nodesc

var _template = {
	"_text.list": '<ul class=\"links sackersgothicstdlight size26\">\n\t<li for-each=\"text\">{{.}}</li>\n</ul>',
    "two.images": "<ul class=\"th_img\">\n    <li>\n        <div class=\"graph-title-1\">\n            <p class=\"novelsansrdprolight size20\">Vorher*</p>\n        </div>\n        <div class=\"th_img1\"></div>\n    </li>\n    <li>\n        <div class=\"graph-title-2\">\n            <p class=\"novelsansrdprolight size20\">Nachher*</p>\n        </div>\n        <div class=\"th_img2\"></div>\n    </li>\n</ul>              \n                    \n<ul class=\"graph_list\">\n\t<li for-each=\"graphList\" if=\"graphList\">{{.}}</li>\n</ul>\n",
    "text.box": '<div class=\"text-box\">{{text}}</div>',
    "_big.nr": "<div class=\"big-nr {{class}}\">\n\t<span class=\"sackersgothicstdheavy size50\">{{nr}}</span>\n    <div class=\"text-align size19 \">{{text}}</div>\n </div>\n",
    "carousel.panel": "<div class=\"panel\" tab=\"panel-{{$index}}\">\n    <div>\n\t    <p for-each=\"content\">\n\t        <strong class=\"novelsansrdprobold\">{{.header}}</strong>\n\t        <br> {{.text}}\t        \n\t    </p>\n\n\t\t<ol class=\"novelsansrdpro-regular {{olClass}}\" if=\"ol\" >\n\t\t    <li for-each=\"ol\">{{.}}</li>\n\t\t</ol>\n\n    </div>\n</div>\n",
    "carousel": "<div class=\"circular-carousel\">\n    <ul class=\"c-nav\">\n        <li class=\"c-btn1 c-link\" show-only=\"panel-1\" ></li>\n        <li class=\"c-btn2 c-link\" show-only=\"panel-2\" ></li>\n        <li class=\"c-btn3 c-link\" show-only=\"panel-3\" ></li>\n        <li class=\"c-btn4 c-link\" show-only=\"panel-4\" ></li>\n        <li class=\"c-btn5 c-link\" show-only=\"panel-5\" ></li>\n        <li class=\"c-btn6 c-link\" show-only=\"panel-6\" ></li>\n    </ul>\n    <div class=\"c-content\">\n\n        <div class=\"scroller size14\">\n            <div tpl=\"panels\"></div>\n        </div>\n\n    </div>\n</div>\n",
    "home": "<div>\n\t<div class=\"heading\">\n\t    <h2>{{header}}</h2>\n\t    <p class=\"info novelsansrdprosemibold size15\">\n\t        <strong>{{subHeader}}</strong>\n\t    </p>\n\t</div>\n\t<div class=\"sub-section sackersgothicstdlight size19\" if=\"menu\">\n\t    <ul class=\"menu\">\n\t        <li for-each=\"menu\" show-slide=\"{{.slide}}\" >{{.name}}</li>\n\t    </ul>\n\t</div>\n\t<button class=\"placeh home-path\" show-slide=\"00.00.10\" if=\"button\"></button>\n\t<div class=\"disclaimer\">{{disclaimer}}</div>\n\t<footer>{{slideName}}</footer>\t\n</div>",
    "twin.enter": "<div class=\"title-page\">\n\t<div class=\"entrance\">\n\t    <div class=\"left\">\n\t        <button show-slide=\"{{button1}}|left\"></button>\n\t        <h3 class=\"sackersgothicstdlight size20\">{{title1}}</h3>\n\t        <div class=\"disclaimer\">\n\t\t\t\t<div for-each=\"disclaimer\">{{.}}</div>\t            \n\t        </div>\n\t    </div>\n\t    <div class=\"right\">\n\t        <div class=\"arrow\"></div>\n\t        <button show-slide=\"{{button2}}|right\"></button>\n\t        <h3 class=\"sackersgothicstdlight size20\">{{title2}}</h3>\n\t    </div>\n\t    <div class=\"graph-txt sackersgothicstdlight size18\"><h2>{{header}}</h2></div>\n\t</div>\n\t<footer>{{slideName}}</footer>\t\n</div>",
    "single.graph": "<div class=\"background_image10\">\n    <div>\n        <div class=\"graph-txt sackersgothicstdlight size29\">{{header}}</div>\n        <div class=\"graph-btn-large\" show-slide=\"{{popup}}\" if=\"popup\"><a class=\"sackersgothicstdheavy size12\">{{button}}</a></div>\n    </div>\n    <div class=\"graph-container-large\">\n\n        <div tpl=\"content\"></div>\n\n        <div class=\"graph-title-text novelsansrdproextralight size21\"><p>{{title}}</p></div>\n                   \n    \t<div class=\"graph-img-{{graphImg}}\">\n    \t\t<div for-each=\"div\" class=\"{{.class}}\">{{.name}}</div>\n        </div>\n        <div class=\"graph-content\">\n            <div class=\"graph-text\">\n                <p for-each=\"paragraphText\" if=\"paragraphText\">{{.}}</p>\n                <p class=\"txt-ident\" for-each=\"identText\" if=\"identText\">{{.}}</p>\n            </div> \n\n            <div class=\"graph-box-large novelsansrdproextralight size21\"><p>{{text}}</p></div>\n            <div class=\"graph-footnote novelsansrdprolight size11\">\n                <p for-each=\"disclaimer\">{{.}}</p>\n            </div>\n        </div>\n\n    </div>\n\n    <ul class=\"nav\">\n        <li for-each=\"navigation\" class=\"{{.class}} rows-{{.$length}}\" show-slide=\"{{.slide}}\"><span></span></li>\n    </ul>\n\t\n\t<div class=\"drag_button {{slider.position}}\" if=\"slider\" show-slide=\"{{slider.slide}}\">\n\t    <span>{{slider.name}}</span>\n\t</div>\n\n\t<footer>{{slideName}}</footer>\n</div>\n",
    "small": "<div class=\"small\">\n    <h1>{{header}}</h1>\n\n    <ul class=\"nav\">\n        <li for-each=\"navigation\" class=\"{{.class}} rows-{{.$length}}\" show-slide=\"{{.slide}}\"><span></span></li>\n    </ul>\n\n    <div class=\"content\">\n        <div tpl=\"child\">dynamic template</div>\n    </div>\n\n    <div class=\"disclaimer\">\n        &nbsp;&nbsp; 1&nbsp;&nbsp;&nbsp; HUMIRA<sup>&reg;</sup>-Fachinformation, Stand September 2013\n        <br />&nbsp;&nbsp; 7&nbsp;&nbsp;&nbsp; Burmester G, et al. Ann Rheum Dis 2013;72: 517-524\n        <br />&nbsp;&nbsp; 9&nbsp;&nbsp;&nbsp; Van de Putte LBa, et al. arthritis rheum 1998;41&nbsp; (Suppl9):S57\n        <br />18&nbsp;&nbsp; Data on file AbbVie Inc. 2013\n    </div>\n</div>\n",
    "product": "<div class=\"background_image10\">\n    <div class=\"graph-container-large\">\n        <div class=\"graph-img\"></div>\n        <div class=\"graph-content\">\n            <ul class=\"ucase sackersgothicstdmedium size24\">\n                <li for-each=\"text\">{{.}}</li>\n            </ul>\n            <div class=\"graph-box-large\"></div>\n            <div class=\"graph-footnote\">\n                <p for-each=\"paratext\">{{.}}</p>\n            </div>\n        </div>\n    </div>\n</div>",
    "medium": "<div class=\"carousel\">\n    <h1>{{header}}</h1>\n\n    <ul class=\"nav\">\n        <li for-each=\"navigation\" class=\"{{.class}} rows-{{.$length}}\" show-slide=\"{{.slide}}\"><span></span></li>\n    </ul>\n\n    <div class=\"content\">\n        <div tpl=\"child\">dynamic template</div>\n    </div>\n\n    <div class=\"disclaimer\">{{disclaimer}}</div>\n</div>\n",
    "product": "<div class=\"background_image10\">\n    <div class=\"graph-container-large\">\n        <div class=\"graph-img\"></div>\n        <div class=\"graph-content\">\n            <ul class=\"ucase sackersgothicstdmedium size24\">\n                <li for-each=\"text\">{{.}}</li>\n            </ul>\n            <div class=\"graph-box-large\"></div>\n            <div class=\"graph-footnote\">\n                <p for-each=\"paratext\">{{.}}</p>\n            </div>\n        </div>\n    </div>\n</div>",
    "popup": "<div class=\"popup\">\n    <div class=\"background_image10\">\n        <div class=\"buttons\" if=\"buttons\">\n            <button for-each=\"buttons\" show-slide=\"{{.slide}}\" class=\"{{.class}}\">{{.name}}</button>\n        </div>\n\n        <div>\n            <div class=\"graph-txt\">{{header}}</div>\n            <div class=\"main_content\">\n                <div class=\"titlelist novelsansrdproextralight size21\">{{title}}</div>\n                <div class=\"close\" show-slide=\"{{back}}\"></div>\n                <p class=\"main_parah novelsansrdproextralight size20\" if=\"paragraphText\">{{paragraphText}}</p>\n\n                <ul class=\"leftcolumn novelsansrdproextralight size20\">\n                    <li for-each=\"text\">{{.}}</li>\n                </ul>\n                <div class=\"deftxt novelsansrdprolight size11\">\n                <div for-each=\"disclaimer\">{{.}}</div></div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"drag_button {{slider.position}}\" if=\"slider\" show-slide=\"{{slider.slide}}\">\n        <span>{{slider.name}}</span>\n    </div>\n\n    <footer>{{slideName}}</footer>    \n</div>\n",
}
 
var feedback_track;
function trackFeedback(){}


