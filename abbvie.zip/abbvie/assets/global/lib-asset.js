var slideName;
var lib_asset = function() {
    var that = this;
    var tarEvent = "mousedown touch";
    this.parent = false;
    this.animating = false;
    this.fromClass = 'on-click';
    this.cache = {};
    
    Array.prototype.last = function() {return this[this.length-1];}

    //---------------------------------------------------
    //  Navigation map

    this.navigation = [];

    //---------------------------------------------------
    // Mindy
    // takes navigation data from sessionStorage and refresh it if first slide is opened

    this.fetchNavigation = function(data) {
        //var sessionNav = sessionStorage.getItem('navigation');
        //if (slideName != navigation[0] && sessionNav)
        //  return JSON.parse(sessionNav);
        var slideNav = {};
        for (var i=0; data[i]; i++) {
            var current = data[i];
            var prev = data[i-1];
            var next = data[i+1];
            if (typeof current == 'object') {
                for (var j=0; current[j]; j++) {
                    // if (j!=0)
                    //  prev = current[j-1];

                    slideNav[current[j]] = {
                        prev: prev,
                        next: next
                    };
                };
            } else {
                slideNav[current] = {
                    prev: prev,
                    next: next
                };
            }
        }
        var first = (typeof data[0] == 'object') ? data[0][0]:data[0];
        var last = (typeof data[i-1] == 'object') ? data[i-1][0]:data[i-1];
        slideNav[last].next = first;

        return slideNav;
    };
    //---------------------------------------------------

    //---------------------------------------------------
    // Mindy
    // navigates next / previous from navigation settings

    this.moveStoredSlide = function(opt) {

        var slideNav = this.fetchNavigation(this.navigation);
        var currentSlide = slideNav[slideName];
        var goTo;

        if (!currentSlide)
            return;

        if (typeof currentSlide[opt] == 'string')
            goTo = currentSlide[opt];

        if (typeof currentSlide[opt] == 'object')
            goTo = currentSlide[opt][0];

        // back by history
        // if (opt == 'prev' && typeof currentSlide.prev == 'object') {
        //  if (currentSlide.from) {
        //      for (var k=0; currentSlide.prev[k]; k++) {
        //          if (currentSlide.prev[k] == currentSlide.from)
        //              goTo = currentSlide.from;
        //      }
        //  }
        // }

        if (opt == 'next') {
            if (!slideNav[goTo])
                slideNav[goTo] = {};

            slideNav[goTo].from = slideName;
        };

        // sessionStorage.setItem('navigation', JSON.stringify(slideNav));
        // alert(goTo);
        if (goTo != undefined)
        {
            var $slideHolder = $('article[slide]');
            that.updateTpl($slideHolder, goTo, true);
            nav.navSlide(goTo);
        } else
        {
            //nav.navSlide("00.00.10");
        }

    };

    //---------------------------------------------------
    this.logEvents = {
        button: function(type, meta) {
            Button_Click(new ESPButton(meta.trackId, meta.keywords));

            console.log('Button --> ',type, meta.trackId, meta.keywords);
        },
        popup: function(type, meta) {
            Popup_Opened(new ESPPopup(meta.trackId, meta.keywords));
            console.log('Popup --> ', type, meta.trackId, meta.keywords);
        },
        page: function(type, meta) {
            Button_Click(new ESPButton(meta.trackId, meta.keywords));
            console.log('Page --> ', type, meta.trackId, meta.keywords);
        }
    }

    //---------------------------------------------------
    this.logOnClick = function(from, to, data) {

        var meta;
        if (data)
            if (data[to])
                meta = data[to];

        if (meta) 
            if (meta.type)
                if (this.logEvents[meta.type.toLowerCase()]) 
                    this.logEvents[meta.type.toLowerCase()]('click', meta);
    }

    //---------------------------------------------------
    this.logOnLoad = function(id, meta) {
        if (meta) 
            if (meta.type)
                if (this.logEvents[meta.type.toLowerCase()]) 
                    this.logEvents[meta.type.toLowerCase()]('load', meta);
    }
    //---------------------------------------------------


    //-----------------------------------------------------------
    // Compile string
    this.compileStr = function(str, data, test) {
    	return str.replace(/\{\{(.+?)\}\}/g, function(match, contents, offset, s) {
			var index = contents.replace(/ /g, '');
			var multi = index.split('.');
			if (!data)
				data = '';

			if (multi.length > 1) {
				var result; 
    			var subData = data;

				for(var i=0; multi.length > i; i++) {
					if (subData[multi[i]]) {
						subData = subData[multi[i]];
					} else {
						subData = '';
					}
				}

                if (typeof subData == 'number')
                    subData = subData.toString();

                if ($.isArray(subData))
                    subData = subData.join('<br>');

				if (index == '.')
					subData = data[''];

				return subData;
			}

	        if (data[index] != undefined) {

                if ($.isArray(data[index]))
                    return data[index].join('<br>');
		        return data[index];
            } else
		    	return '';
	    });
    };


    //-----------------------------------------------------------
    // PreCompile [for-each]
    this.compileForEach = function($body, data) {
        $body.find('[for-each]').replaceWith(function(index, value) {
            if (!data)
                return;

            var param = $(this).attr('for-each');
            var $self = $(this);
            $self.removeAttr('for-each');
            var template = $self[0].outerHTML;
            var innerData = data[param];
            var result = '';

            if (!innerData)
                return '';

            if (typeof innerData == 'object')
                $.each(innerData, function(i, v) {
                    data[""] = v;
                    data[""].$length = innerData.length;
                    data[""].$index = i;
                    result += that.compileStr(template, data, 1);
                });
            else
                result += that.compileStr(template, {"":innerData});

            return result;
        });

        return $body;
    };

    //-----------------------------------------------------------
    // PreCompile [slide]
    this.compileSlide = function($body, data) {
        $body.find('[slide]').html(function(index, value) {
            var param = $(this).attr('slide');
            var $self = $(this);
            // $self.removeAttr('slide');

            var result = that.updateTpl($(value), param);
            return result;
        });

        return $body;
    };

    //-----------------------------------------------------------
    // PreCompile [if]
    this.compileIf = function($body, data) {
        $body.find('[if]').each(function(index, value) {
            var param = $(this).attr('if');
            if (!data)
                $(this).remove();
            else
                if (!data[param])
                    $(this).remove();
        });

        return $body;
    };

    //-----------------------------------------------------------
    // PreCompile [tpl]
    this.compileTpl = function($body, data) {
        if (!data)
            return;
        $body.find('[tpl]').replaceWith(function(index, value) {
            var i;
            var result = '';
            var template;
            var param = $(this).attr('tpl');
            var $self = $(this);
            // $self.removeAttr('slide');

            param = param.split('.');

            var subData = data[param];
            for (i=0; param[i]; i++) {
                subData = data[param[i]];
                data = subData;
            }

            if (!subData)
                return;

            if ($.isArray(subData)) {
                for (i=0; subData[i]; i++) {
                    subData[i].$index = i;
                    subData[i].$length = subData.length;
                    template = _template[subData[i].tpl];
                    result += that.compile(template, subData[i]);
                }
            } else {
                template = _template[subData.tpl];
                result = that.compile(template, subData);
            }
            return result;
        });

        return $body;
    };

    this.compile = function(body, data) {
        if (!data)
            return;

        var $body = $(body);
		$body = that.compileForEach($body, data);
        $body = that.compileSlide($body, data);
        $body = that.compileIf($body, data);
        $body = that.compileTpl($body, data);

    	var subBody = '';
    	$body.each(function(index, value) {
    		var outer = $(this)[0].outerHTML

    		if (!outer)
    			outer = "\n";
    		subBody += outer+"\n";
    	});

    	return that.compileStr(subBody, data);
    	
    };

    this.updateExtendedTpl = function($div, tplName, child, after) {
        var parent = child.extend;

        $.get('assets/'+parent+'.json').then(function(response) {

            response = jQuery.extend(response, child);

            that.render($div, tplName, response, after);
        });
    }

    this.animate = function($div, $compiled, data, after) {
        if (after) {
            var $clone = $div.clone();
            
            $div.before($clone.html($compiled));
            
            $clone.addClass(that.fromClass+' animation-enter');
            if (data)
                if (data.id)
                    $clone.attr('id', data.id);
                else
                    $clone.removeAttr('id');
            
            that.animating = true;
            setTimeout(function() {
                $clone.removeClass(that.fromClass+' animation-enter');
                $div.addClass(that.fromClass+' animation-exit');
            }, 50);
            setTimeout(function() {
                $div.remove();
                that.animating = false;
            }, 550);
        } else {
            if (data)
                if (data.id)
                    $div.attr('id', data.id);
                else
                    $div.removeAttr('id');

            $div.html($compiled);
        }

    };

    this.updateTpl = function($div, tplName, after) {
        console.log('tpl loaded: -->', tplName, data);

        // that.cache[tplName] = data;
        var data = config[tplName];
        if (slide[tplName])
            data = jQuery.extend(data, slide[tplName]);

        if (that.action == 'click')
            that.logOnClick(slideName, tplName, data);
        that.logOnLoad(tplName, data);

        this.data = data;

        if (data) {
            if (data.slideName)
                slideName = data.slideName;
            else {

                if (data.slideName !== 'false') {
                    slideName = tplName;
                }
                data.slideName = tplName;
            }

            if (data.extend)
                data = jQuery.extend(config[data.extend], data);

            if (data.tpl)
                tplName = data.tpl;

            if (data.class)
                $div.addClass(data.class)

        } else {
            slideName = tplName;
            $div.removeAttr('id');
        }

        // data.$parent = that.parent;
        // that.parent = data;

        response = _template[tplName];

        var compiled = that.compile(response, data)
        var $compiled = $(compiled);

        that.animate($div, $compiled, data, after);

        return $compiled; 
    };

    this.init = function($tpl) {
        $tpl.each(function(index, value) {
        	var $singleTpl = $(value);
    	    var name = $singleTpl.attr('slide'); 

    	    that.updateTpl($singleTpl, name);
        });
    }

    
    this.init($('[slide]'));
    
    $('[show-slide]').live(tarEvent, function(event) {
        if (that.animating)
            return;

    	var slide = $(this).attr('show-slide');

        if (!slide)
            return;
        var slideInGroup = slide.split(':');
        var additional = slide.split('|');
        if (additional[1]) {
            that.fromClass = additional[1];
            slideInGroup = additional[0].split(':');
            slide = additional[0];
        } else {
            that.fromClass = 'on-click';
        }

        if (slideInGroup[1]) {
            slide = slideInGroup[1];
            $slideHolder = $('[tpl="'+slideInGroup[0]+'"]');
        } else {

        	var $slideHolder = $(this).closest('[slide]');
        	if ($slideHolder.length == 0) 
        		$slideHolder = $('article[slide]');
        }

        that.action = 'click';
        nav.navSlide(slide);
    	that.updateTpl($slideHolder, slide, true);
    });

    $(document).bind('swipeleft', function() {
        if (that.animating)
            return;
        that.fromClass = "next";
        that.action = "swipeleft";
        that.moveStoredSlide(that.fromClass);
    });

    $(document).bind('swiperight', function() {
        if (that.animating)
            return;
        that.fromClass = "prev";
        that.action = "swiperight";
        that.moveStoredSlide(that.fromClass);
    });

    var showOnly = function(event, obj, tab) {

        event.stopPropagation();
        var redirect = tab.split(':');
        var type;
        var meta;
        var id = redirect.last() 

        that.logOnClick(slideName, id, config[slideName]);

        if (redirect.length == 2) {
            if (type && type != 'page')
                slideLog[type](id);

            window.location.href = redirect[1]+".html";
            return;
        };

        if (type) {
            slideLog[type](id);
        }

        var group,
            allTabs,
            $allTabs;

        var $btn = $(obj),
            tab = (tab) ? tab:$btn.attr('show-only'),
            $btns = $('[show-only="'+tab+'"]'),
            $btns2 = $('[show="'+tab+'"]'),
            $tab = $('[tab="'+tab+'"]'),
            $btnGroup = $btn.closest('[tab-group]');

        group = $btnGroup.attr('tab-group');
        if (group) {            
            allTabs = '[tab-group="'+group+'"] [tab]';
        } else
            allTabs = '[tab]:not([tab-group] [tab])';

        $allTabs = $(allTabs);

        $('.show-active').removeClass('show-active');
        $btns.addClass('show-active');
        $btns2.addClass('show-active');
        $allTabs.addClass('hide');
        $allTabs.removeClass('show');
        $tab.addClass('show');
        $tab.removeClass('hide');
    }

    $('[show-only]').live(tarEvent, function (event) {
        showOnly(event, this, $(this).attr('show-only'));
    });

    $('[swipe-left]').live('swipeleft', function(event) {
        showOnly(event, this, $(this).attr('swipe-left'));
    });

    $('[swipe-right]').live('swiperight', function(event) {
        showOnly(event, this, $(this).attr('swipe-right'));
    });

    return this;
}

$(document).ready(function(){
    var asset = lib_asset(); 
    asset.navigation = [
        ["00.00"], 
        ["00.00.10"], 
        "20.00", 
        ["20.00.10", "20.00.20"], 
        ["20.10", "20.10.10"],
		["30.00", "30.10", "30.20"],
		["40.00", "40.00.10"],
		"50.00",
		"60.00",
		["60.10", "60.10.10"],
		"60.30.10"
    ];

    window.asset = asset;
});