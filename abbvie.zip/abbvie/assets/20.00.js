slide["20.00"] = {
    "id": "page_20_00",
    "tpl": "twin.enter",
    "header": "HUMIRA<sup>&reg;</sup> WIRKT SCHNELL, STARK<br/> UND ANHALTEND<sup>2,3</sup>",
    "title1": "SCHNELL",
    "title2": "ANHALTEND",
    "button1": "20.00.10",
    "button2": "20.10",
    "disclaimer": [
        "2&nbsp;&nbsp;&nbsp;&nbsp; Hanauer S, et al. Gastroenterology 2006; 130: 323-333",
        "3&nbsp;&nbsp;&nbsp;&nbsp; Panaccione R, et al. Aliment Pharmacol Ther 2013; 38:1236-124"
    ]	
};