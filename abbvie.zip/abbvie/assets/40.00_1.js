slide["40.00_1"] = {
    "id": "page_40_00_1",
    "tpl": "popup",
	 "slideName": "40.00_1",
	"header": "",
	"title": "EXTEND Studiendesign<sup>15</sup>",
	"disclaimer": "15&nbsp;&nbsp;&nbsp; Rutgeerts P, et al. Gastroenterology 2012; 142: 1102-1111",
	"text": [
		"Doppelblinde,placebokontrollierte,randomisiertePhase-IV-Studie über 52 Wochen mit 4-wöchiger offenen Induktionsphase zur Induktion und Erhaltung einer Mukosaheilung",
		"Anti-TNF-naiveundInfliximab-erfahrenePatientenmitmittelschwerembis schwerem, aktivem Morbus Crohn, die bei der Screening-Koloskopie in mind. 1 von 5 Darmabschnitten Ulzerationen aufwiesen (N = 135)",
		"PrimärerStudienendpunkt:vollständigeMukosaheilungbeiEndoskopie zur Wo. 12; sek. Endpunkt u.a.: vollständige Mukosaheilung zur Wo. 52",
		"27%bzw.24%unterkontinuierlicherHUMIRA®-BehandlungzurWo.12 bzw. 52 mit vollständig verheilter Mukosa"
	],
	"back": "40.00|popup-out",
};
	
	

