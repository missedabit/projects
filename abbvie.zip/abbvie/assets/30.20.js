slide["30.20"] = {
    "id": "page_30_20",
    "tpl": "medium",
    "header": "HUMIRA<sup>&reg;</sup> WIRKT SCHNELL, STARK<br/> UND ANHALTEND<sup>2,3</sup>",
    "title1": "SCHNELL",
    "title2": "ANHALTEND",
    "button1": "20.00.10",
    "button2": "20.10",
    disclaimer: "10&nbsp;&nbsp;&nbsp; www.abbvie-care.de",
    "navigation": [
        { "slide": "30.00" },
        { "slide": "30.10" },
		 { "class": "active" }
    ],
    child: {
        tpl: "carousel",
        panels: [
            {
                tpl: "carousel.panel",
                olClass: "c-link-txt",
                ol: [
                    "Pers&ouml;nliches Starter-Set",
                    "Mobile Krankenschwester",
                    "Servicetelefon",
                    'Informationen <span class="normal-case novelsansrdprolight">z.B. zum Thema</span>',
                    'ERN&Auml;HRUNG UND REISEN'
                ]
            },
            {
                tpl: "carousel.panel",
                content: [
                    {
                        header: "Ihr pers&ouml;nliches Starter Set",
                        text: [
                            "F&uuml;r Ihre HUMIRA<sup>&#174;</sup>-Therapie mit",
                            "Injektionsanleitung, K&uuml;hltasche,",
                            "Patiententagebuch und weiteren",
                            "praktischen Informationen"
                        ]
                    }
                ]
            },
            {
                tpl: "carousel.panel",
                content: [
                    {
                        header: "Informationen zu HUMIRA<sup>&reg;</sup>",
                        text: "Tipps zur Anwendung, K&uuml;hlung, Lagerung und zum Transport"
                    },
                    {
                        header: "Informationen zu Ihrer Erkrankung",
                        text: "Wissenswertes zum Krankheitsbild"
                    },
                    {
                        header: "Patientenzeitschrift",
                        text: "Aktuelles, Hintergr&uuml;nde und Anregungen rund um die Erkrankung"
                    },
                    {
                        header: "Brosch&uuml;ren zu wechselnden Themen",
                        text: [
                            "Sport, Ern&auml;hrung, Stressbew&auml;ltigung und weitere hilfreiche",
                            "Themen"
                        ]
                    },
                    {
                        header: "Informationen zum Thema Auslandsaufenthalt",
                        text: [
                            "Kurzurlaub, Rucksackreise, Auslandssemester,",
                            "Bezugsbedingungen in anderen L&auml;ndern"
                        ]
                    }
                ]
            },
            {
                tpl: "carousel.panel",
                content: [
                    {
                        header: "Service-Telefon",
                        text: [
                            "Individuelle Beratung und Betreuung",
                            "durch das AbbVie Care-Team"
                        ]
                    },
                    {
                        header: "Sozialrecht-Sprechstunden",
                        text: "Telefonischer Expertenrat -individuell und kompetent"
                    },
                    {
                        header: "HUMIRA<sup>&reg;</sup> Pen-Service",
                        text: "Austausch des HUMIRA<sup>&reg;</sup>-Pens bei Bedarf"
                    }
                ]
            },
            {
                tpl: "carousel.panel",
                content: [
                    {
                        header: "Mobile Krankenschwester",
                        text: "Auf Wunsch: Hilfestellung bei der HUMIRA<sup>&reg;</sup>-Injektion"
                    }
                ]
            },
            {
                tpl: "carousel.panel",
                content: [
                    {
                        header: "www.abbvie-care.de",
                        text: [
                            "Internetportal mit vielen News,",
                            "Informationen, Downloads und Links"
                        ]
                    }
                ]
            },
            {
                tpl: "carousel.panel",
                content: [
                    {
                        header: "So funktioniert die Anmeldung:",
                        text: "",
                    }
                ],
                ol: [
                    [
                        "Sie stellen die Diagnose einer mittelschweren bis schweren",
                        "chronisch-entzündlichen Darmerkrankung (CED)."
                    ],
                    [
                        "Sie weisen Ihren Patienten auf das Patienten-Service-",
                        "Programm AbbVie Care hin."
                    ],
                    [
                        "Sie oder Ihre Fachassistentin stellen AbbVie Care",
                        "und das Starter Set vor."
                    ],
                    [
                        "Einsendung des unterschriebenen Anmeldeformulars per",
                        "Fax oder Post direkt aus Ihrer Praxis oder durch den Patienten."
                    ],
                    [
                        "Der Patient erh&auml;lt per Post das Starter Set und den",
                        "ersten Anruf durch das AbbVie Care-Team."
                    ]
                ]
            },
        ]
    }	
};