slide["40.00"] = {
    "id": "page_40_00",
    "tpl": "single.graph",
    "header": "MIT HUMIRA<sup>®</sup>DIE MUKOSA<br>FRÜHZEITIG HEILEN!<sup>8,12,13,14</sup>", 
	"text": "Handeln Sie frühzeitig, um langfristig zu helfen!",
	"disclaimer": [
		"&nbsp;&nbsp;&nbsp;8&nbsp;&nbsp;&nbsp; Rutgeerts P, et al. J Crohn’s Colitis 2010; 3 (1): S37",
		"12&nbsp;&nbsp;&nbsp; Sandborn WJ, et al. Gastroenterology; 38 (5 Suppl 1): S-164/DDW2010; S1031",
		"13&nbsp;&nbsp;&nbsp; Rutgeerts P, et al. ECCO 2010; P061",
		"14&nbsp;&nbsp;&nbsp; Geboes K, et al. Gut 2009; 58 (Suppl II): A326 &ndash; 327"          
	], 
	"identText": [
            "* Endoskopiebilder: unveröffentlichte Daten nach 6 Monaten Therapie mit HUMIRA®, data on file, mit freundlicher Genehmigung Dres. Felten, Hartmann, Hüppe; 				Gastroenterologische Gemeinschaftspraxis Herne."
        ],
	"button": "ZUR STUDIE",
	"popup": "40.00_1|popup-in",
	"back": "40.00|popup-out",
	content: {
		"tpl":"two.images",
		"header1": "Vorher*",
		"header2": "Nachher*",
			graphList: [
				'Frühe Mukosaheilung durch frühzeitigen Einsatz<sup>12</sup>',
				'Weniger Schübe durch frühe Mukosaheilung<sup>8,13</sup>',
				'Verbesserte Lebensqualität durch frühe<br>Mukosaheilung<sup>14</sup>'
			]
		},
    "navigation": [
        { "class": "active" },
        {  "slide": "40.00.10"  }
    ] 	
};
	

