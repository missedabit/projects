slide["60.10"] = {
    "id": "page_60_10",
    "tpl": "small",
    "header": "THERAPIE- UND PATIENTENMANAGEMENT GEMEINSAM GESTALTEN: UNSERE FORT- BILDUNGSANGEBOTE FÜR SIE UND IHR TEAM",
    child: [
        {
            tpl: "_text.list",
            text: [
				'CURRICULUM',
				'IBD HEAD',
				'CED FACHASSISTENZ',
				'BIO-LOGICUM',
				'COMPLIANCE-KOLLEG',
				'CED REGIONALVERANSTALTUNGEN'
			]
        },
    ],
    "navigation": [
        { "class": "active"  },
        { "slide": "60.10.10" }
    ]                   
};