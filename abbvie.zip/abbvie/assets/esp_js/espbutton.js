/*
   ESPButton.js 
   Author: SKW
   Version: 1.1
   Created: 11/09/2010
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESP Button class.
   This class is used to make button tracking calls from the content to the host ESP application.
*/

/* 
   ESP Button class.
*/
function ESPButton(trackId, description)
{
	/* Private trackID variable */
	this.m_trackID = "BUTTON";

	/* Private description variable */
	this.m_description = "";

	/* Private submitted variable that will be set to true after the button is submitted */
	this.m_submitted = false;

	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}
	
/*
   All track items must have this property return true
*/
ESPButton.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPButton.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// Button node
  	trackItemNode.appendChild( xmlDoc.createElement( "Button" ) );
  	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPButton.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPButton.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Returns true if the button has been submitted.
*/
ESPButton.prototype.IsSubmitted = function()
{
	return this.m_submitted;
}

/*
   Submits tracking that this button was clicked.
	
	returns:	CallID of CCAPI request, used to identify response in myCallback	
*/
ESPButton.prototype.Submit = function()
{		
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID);
	
	//trace("Button with trackID: "+this.m_trackID+" has been submitted");
	
	this.m_submitted = true;
	
	// Return the callID so caller can identify it in myCallback
	return callID;
}

/*
   Button Click function: Pass in the name of the button you want to track
*/
function Button_Click(e)
{
	//trace("Button_Click");
	 /* alert(" Clicked >> "+e.clicked);  */
	if(e.clicked!=true){
		var res = e.Submit();
	}
	e.clicked=true;
	console.log("<<<<<<<<<<<<<<<<<<<< Button_Click >>>>>>>>>>>>>>>>>> ");
	// $.each(e, function( key, value ) {
	// 	if(key=="m_trackID" || key=="m_description"){
	// 		 alert( key + ": " + value );  
	// 	}
	// });
	//trace( "Submit res=" + res);
}
// Create an instance of the ESPButton class so it will be initialized
espbutton = new ESPButton();
