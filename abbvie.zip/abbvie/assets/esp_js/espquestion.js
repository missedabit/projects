/*
   ESPQuestion.js 
   Author: MJR
   Version: 1.1
   Created: 05/13/2011
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESPQuestion class.
   This class is used to make survey tracking calls from the content to the host ESP application.
*/

/* 
   ESP Question class.
*/
function ESPQuestion(trackId, description, message, type, answers, requireCount)
{
	/* Question constants */
	ESPQuestion.CHOOSEONE 	= "chooseone";
	ESPQuestion.MULTI 	= "multi";
	ESPQuestion.ORDER 	= "order";
	ESPQuestion.TEXT 	= "text";
		
	/* Private trackID variable */
	this.m_trackID = "SURVEY";

	/* Private description variable */
	this.m_description = "";
	
	/* Private message variable */
	this.m_message = "";
	
	/* Private type variable */
	this.m_type = ESPQuestion.CHOOSEONE;
	
	/* Empty array of string answers */
	this.Answers = [];
	
	/* Empty array of external system identifiers.
	   Set as needed to associate ext sys ids with answer at same index. */
	this.ExternalSystemIDs = [];
	
	/* Private require count variable */
	this.m_requireCount = 1;

	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	this.SetMessage( message );
	this.SetType( type );
	this.SetAnswers( answers );
	this.SetRequireCount( requireCount );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}

/*
   All track items must have this property return true
*/
ESPQuestion.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPQuestion.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// Survey node
  	var surveyNode = xmlDoc.createElement( "Survey" );
  	trackItemNode.appendChild( surveyNode );
  	// Question node
  	var questionNode = xmlDoc.createElement( "Question" );
  	// Type attribute
  	attr = xmlDoc.createAttribute( "Type" );
  	attr.nodeValue = this.m_type;
  	questionNode.setAttributeNode( attr );
  	// RequireCount attribute
  	attr = xmlDoc.createAttribute( "RequireCount" );
  	attr.nodeValue = this.m_requireCount;
  	questionNode.setAttributeNode( attr );
  	// Message text node
  	questionNode.appendChild( xmlDoc.createTextNode( this.m_message ) );
  	surveyNode.appendChild( questionNode );
  	// Each Answer node (if this isn't a text survey)
  	if ( this.m_type != ESPQuestion.TEXT )
  	{
	  	for ( var i = 0; i < this.Answers.length; i++ )
	  	{
	  		// Answer node
	  		var answerNode = xmlDoc.createElement( "Answer" );
	  		// ExternalSystemID attribute
	  		if ( i < this.ExternalSystemIDs.length )
	  		{
	  			attr = xmlDoc.createAttribute( "ExternalSystemID" );
	  			attr.nodeValue = this.ExternalSystemIDs[i];
	  			answerNode.setAttributeNode( attr );
	  		}
	  		// Answer text node
	  		answerNode.appendChild( xmlDoc.createTextNode( this.Answers[i] ) );
	  		surveyNode.appendChild( answerNode );
	  	}
	}

  	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPQuestion.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPQuestion.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Sets the message. Which is the actual text of the question.
*/
ESPQuestion.prototype.SetMessage = function(message)
{
	this.m_message = message;
}

/*
   Sets the type.
*/
ESPQuestion.prototype.SetType = function(type)
{
	if ( typeof type != "undefined" )
		this.m_type = type;
}

/*
   Sets the answers.
*/
ESPQuestion.prototype.SetAnswers = function(answers)
{
	if ( typeof answers != "undefined" )
		this.Answers = answers;
}

/*
   Sets the requireCount.
*/
ESPQuestion.prototype.SetRequireCount = function(requireCount)
{
	if ( typeof requireCount != "undefined" )
		this.m_requireCount = requireCount;
}

/*
   Submits an answer or array of answers for the survey.
	answer:		Answer as integer, array of integers, or string depending on survey type
	
	returns:	CallID of CCAPI request, used to identify response in myCallback	
*/
ESPQuestion.prototype.Submit = function(answers)
{
	// Get the track xml to submit
	var xml = this.GetTrackXml( answers );
	
	//trace(xml);
	
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID, xml);

	// Return the callID so caller can identify it in myCallback
	return callID;
}


/*
   Returns the xml string to submit to the host ESP application for the track data.
	answers:	single integer, array of integers, or string depending on survey type
	
	returns:	Xml string of track data for the passed answer index.	
*/
ESPQuestion.prototype.GetTrackXml = function(answers)
{
	// Create the XML by hand for now
	var xml = "<Track><Answers>";


	if (typeof answers == "object")		/* array of integers */
	{
		for (idx = 0; idx < answers.length; idx++)
			xml = xml + "<Answer>" + answers[idx] + "</Answer>";
	}
	else if (typeof answers == "string")
	{
		xml = xml + "<Answer>" + encodeXmlText(answers) + "</Answer>";   /* single string */
	}	
	else
	{
		xml = xml + "<Answer>" + answers + "</Answer>";   /* single integer */
	}

	xml = xml + "</Answers></Track>";
	return xml;
}

function Question_Submit( q, answers )
{
	q.Submit(answers);	
}

// Create an instance of the ESPQuestion class so it will be initialized
espquestion = new ESPQuestion();
