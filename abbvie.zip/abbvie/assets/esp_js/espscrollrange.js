/*
   ESPScrollRange.js 
   Author: MJR
   Version: 1.1
   Created: 05/13/2011
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESPScrollRange class.
   This class is used to make survey tracking calls from the content to the host ESP application.
*/


/* 
   ESP ScrollRange class.
*/
function ESPScrollRange(trackId, description, min, max)
{
	/* Private trackID variable */
	this.m_trackID = "SCROLLRANGE";

	/* Private description variable */
	this.m_description = "";

	/* Private minimum value variable */
	this.m_minValue = 0;

	/* Private maximum value variable */
	this.m_maxValue = 100;

	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	this.SetMinValue( min );
	this.SetMaxValue( max );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}

/*
   All track items must have this property return true
*/
ESPScrollRange.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPScrollRange.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// Range node
  	var rangeNode = xmlDoc.createElement( "Range" );
  	trackItemNode.appendChild( rangeNode );
  	// MinValue node
  	var minValueNode = xmlDoc.createElement( "MinValue" );
  	minValueNode.appendChild( xmlDoc.createTextNode( this.m_minValue ) );
  	rangeNode.appendChild( minValueNode );
  	// MaxValue node
  	var maxValueNode = xmlDoc.createElement( "MaxValue" );
  	maxValueNode.appendChild( xmlDoc.createTextNode( this.m_maxValue ) );
  	rangeNode.appendChild( maxValueNode );
  	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPScrollRange.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPScrollRange.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Sets the minimum value.
*/
ESPScrollRange.prototype.SetMinValue = function(min)
{
	if ( typeof min != "undefined" )
		this.m_minValue = min;
}

/*
   Sets the maximum value.
*/
ESPScrollRange.prototype.SetMaxValue = function(max)
{
	if ( typeof max != "undefined" )
		this.m_maxValue = max;
}

/*
   Submits the ScrollRange scroll position
	percentScrolled:  integer scroll position percentage
	
	returns:  CallID of CCAPI request, used to identify response in myCallback
*/
ESPScrollRange.prototype.Submit = function(percentScrolled)
{
	// Get the track xml to submit
	var xml = this.GetTrackXml( percentScrolled );
	
	//trace(xml);
	
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID, xml);
	
	// Return the callID so caller can identify it in myCallback
	return callID;
}

/*
   Returns the xml string to submit to the host ESP application for the track data.
	percentScrolled:  integer scroll position percentage
	
	returns:	Xml string containing tracking data
*/
ESPScrollRange.prototype.GetTrackXml = function(percentScrolled)
{
	// Create the XML by hand for now
	var xml = "<Track><Value>" + percentScrolled + "</Value></Track>"

	return xml;
}

function ScrollRange_Track( s, percentScrolled )
{
	s.Submit(percentScrolled)
}

// Create an instance of the ESPScrollRange class so it will be initialized
espscrollrange = new ESPScrollRange();
