/*
   ESPToggleButton.js 
   Author: MJR
   Version: 1.1
   Created: 05/13/2011
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESP ToggleButton class.
   This class is used to make ToggleButton tracking calls from the content to the host ESP application.
*/

/* 
   ESP ToggleButton class.
*/
function ESPToggleButton(trackId, description)
{
	/* Private trackID variable */
	this.m_trackID = "TOGGLEBUTTON";

	/* Private description variable */
	this.m_description = "";

	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}
	
/*
   All track items must have this property return true
*/
ESPToggleButton.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPToggleButton.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// ToggleButton node
  	trackItemNode.appendChild( xmlDoc.createElement( "ToggleButton" ) );
  	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPToggleButton.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPToggleButton.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Submits state of toggle button
	on:		boolean button state
	
	returns:	CallID of CCAPI request, used to identify response in myCallback	
*/
ESPToggleButton.prototype.Submit = function(on)
{		
	// Get the track xml to submit
	var xml = this.GetTrackXml( on );
	
	//trace(xml);
	
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID, xml);

	// Return the callID so caller can identify it in myCallback
	return callID;
}

/*
   Returns the xml string to submit to the host ESP application for the track data.
	on:		button state
	
	returns:	Xml string containing tracking data	
*/
ESPToggleButton.prototype.GetTrackXml = function(on)
{
	// Create the XML by hand for now
	var xml = "<Track><On>" + on + "</On></Track>";
	return xml;
}


function ToggleButton_ToggleOn(p)
{
	p.Submit(true);
}

function ToggleButton_ToggleOff(p)
{
	p.Submit(false);
}

// Create an instance of the ESPToggleButton class so it will be initialized
esptogglebutton = new ESPToggleButton();
