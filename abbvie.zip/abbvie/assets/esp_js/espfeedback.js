/*
   ESPFeedback.js 
   Author: SKW
   Version: 1.1
   Created: 05/12/2011
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESP Feedback class.
   This class is used to make feedback tracking calls from the content to the host ESP application.
*/

/*
   If there is no indexOf prototype in the host browser then define one.
*/
if (!Array.prototype.indexOf)
{
  Array.prototype.indexOf = function(elt /*, from*/)
  {
    var len = this.length;

    var from = Number(arguments[1]) || 0;
    from = (from < 0)
         ? Math.ceil(from)
         : Math.floor(from);
    if (from < 0)
      from += len;

    for (; from < len; from++)
    {
      if (from in this &&
          this[from] === elt)
        return from;
    }
    return -1;
  };
}

/* 
   ESP Feedback class.
*/
function ESPFeedback(trackId, description, message)
{
	/* Feedback constants */
	ESPFeedback.MET 	= 0;
	ESPFeedback.NEUTRAL 	= 1;
	ESPFeedback.NOTMET 	= 2;
	
	/* The three feedback button parameters 
	0 = Accept, Positive , Very Compelling
	1 = Neutral, Moderately Compelling
	2 = Reject, Not Compelling, Negative
	*/
	ESPFeedback.Answers = [ "met the customer needs", "Neutral", "Did not meet the customer needs" ];
	
	/* Empty array of external system identifiers.
	   Set as needed to associate ext sys ids with answer at same index. */
	this.ExternalSystemIDs = [];

	/* Private trackID variable */
	this.m_trackID = "FEEDBACK";

	/* Private description variable */
	this.m_description = "";

	/* Private message variable that holds the message for this feedback survey question */
	this.m_message = "";

	/* Private submitted variable that will be set to true after the feedback is submitted */
	this.m_submitted = false;

	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	this.SetMessage( message );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}

/*
   All track items must have this property return true
*/
ESPFeedback.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPFeedback.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// Survey node
  	var surveyNode = xmlDoc.createElement( "Survey" );
  	trackItemNode.appendChild( surveyNode );
  	// Question node
  	var questionNode = xmlDoc.createElement( "Question" );
  	// Type attribute
  	attr = xmlDoc.createAttribute( "Type" );
  	attr.nodeValue = "feedback";
  	questionNode.setAttributeNode( attr );
  	// RequireCount attribute
  	attr = xmlDoc.createAttribute( "RequireCount" );
  	attr.nodeValue = "1";
  	questionNode.setAttributeNode( attr );
  	// Message text node
  	questionNode.appendChild( xmlDoc.createTextNode( this.m_message ) );
  	surveyNode.appendChild( questionNode );
  	// Each Answer node
  	for ( var i = 0; i < ESPFeedback.Answers.length; i++ )
  	{
  		// Answer node
  		var answerNode = xmlDoc.createElement( "Answer" );
  		// ExternalSystemID attribute
  		if ( i < this.ExternalSystemIDs.length )
  		{
  			attr = xmlDoc.createAttribute( "ExternalSystemID" );
  			attr.nodeValue = this.ExternalSystemIDs[i];
  			answerNode.setAttributeNode( attr );
  		}
  		// Answer text node
  		answerNode.appendChild( xmlDoc.createTextNode( ESPFeedback.Answers[i] ) );
  		surveyNode.appendChild( answerNode );
  	}

  	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPFeedback.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPFeedback.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Sets the message.
*/
ESPFeedback.prototype.SetMessage = function(message)
{
	this.m_message = message;
}

/*
   Returns true if the feedback has been submitted.
*/
ESPFeedback.prototype.IsSubmitted = function()
{
	return this.m_submitted;
}

/*
   Submits an answer for the feedback survey.
	answer:		Answer index.
	
	returns:	CallID of CCAPI request, used to identify response in myCallback	
*/
ESPFeedback.prototype.Submit = function(answer)
{	
	// If the answer index is out of range let caller know we could not submit
	if ( answer < 0 || answer >= ESPFeedback.Answers.length )
		return false;
		
	// Get the track xml to submit
	var xml = this.GetTrackXml( answer );
	
	//trace(xml);
	
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID, xml);
	
	this.m_submitted = true;
	
	// Return the callID so caller can identify it in myCallback
	return callID;
}

/*
   Returns the xml string to submit to the host ESP application for the track data.
	answerIndex:	Zero based integer index of the answer.
	
	returns:	Xml string of track data for the passed answer index.	
*/
ESPFeedback.prototype.GetTrackXml = function(answerIndex)
{
	// Create the XML by hand for now
	var xml = "<Track><Answers>";
	xml = xml + "<Answer>" + answerIndex + "</Answer>";
	xml = xml + "</Answers></Track>";
	return xml;
}

//Feedback click function
function Feedback_Click(feedback, answer)
{
	//trace( "Feedback_Click answer=" + answer );
	var res = feedback.Submit( answer );
	//trace( "feedback.Submit res=" + res );
	console.log("<<<<<<<<<<<<<<<<<<<< Feedback_Click >>>>>>>>>>>>>>>>>> ");
	$.each( feedback, function( key, value ) {
		if(key=="m_trackID" || key=="m_description"){
			 alert( key + ": " + value );  
		}
	});
}


// Create an instance of the ESPFeedback class so it will be initialized
espfeedback = new ESPFeedback();
