/*
   esp.js 
   Author: SKW
   Version: 1.0
   Created: 09/28/2010
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for all ESP system communication and utility functions.
*/

function EVT_slideLoad(mode, data)
{
	//alert("EVT_slideLoad" + mode + data);
	//output("EVT_slideLoad" + mode + data);
	/*trace("EVT_slideLoad" + mode + data);

	var s = "";

	for (var k in data)
	{
		s = s + "data." + k + " = " + data[k] + " ";
	}
	//alert(s);
	//output(s);
	trace(s);*/
}

function EVT_slideStart()
{
	//alert("EVT_slideStart");
	//output("EVT_slideStart");
	//trace("EVT_slideStart");
}

function EVT_slideEnd()
{
	trackFeedback();
	//alert("EVT_slideEnd");
	//output("EVT_slideEnd");
	//trace("EVT_slideEnd");
}

function GetObjectsFromRowColumnXml( xmlString, replaceUndefinedWithDefaultValue )
{

	if (typeof xmlString != 'string' || xmlString == "" )
		return undefined;

	var xml;
	if (window.DOMParser)
	{
		parser=new DOMParser();
		xml=parser.parseFromString(xmlString,"text/xml");
	}
	else // Internet Explorer
	{
		xml=new ActiveXObject("Microsoft.XMLDOM");
		xml.async="false";
		xml.loadXML(xmlString);
	}

	// Get the function name
	var root = xml;
		
	if (root.nodeType == 9) // Document node
	{
		// Get the first child
		root = root.firstChild;
	}

	if (root.childNodes.length != 3)
		return undefined;

	var nodeColumns = root.childNodes[0];
	
	var nodeColumnTypes = root.childNodes[1];

	var nodeRows = root.childNodes[2];

	var colsCount = nodeColumns.childNodes.length;
	var rowsCount = nodeRows.childNodes.length;


	var columns = new Array();
	var columnTypes = new Array();

	for (k = 0; k < colsCount; k++)
	{
		columns[k] = nodeColumns.childNodes[k].firstChild.nodeValue;
		columnTypes[k] = nodeColumnTypes.childNodes[k].firstChild.nodeValue;
	}
	
	var rows = new Array();

	for (index = 0; index < rowsCount; index++)
	{
		rows[index] = new Object();
		var node = nodeRows.childNodes[index];

		var o = rows[index];

		for (k=0; k < colsCount; k++)
		{
			var tempNode = node.childNodes[k].firstChild;
			SetObjectProperty(o, columns[k], columnTypes[k], tempNode, replaceUndefinedWithDefaultValue);
		}
	}

	return rows;
}

function SetObjectProperty(o, key, valueType, valueNode, replaceUndefinedWithDefaultValue)
{
	var valueObject = null;

	if (valueNode != null)
	{
		valueObject = valueNode.nodeValue;
	}

	if (valueType == "string" || valueType == "date")
	{
		if (replaceUndefinedWithDefaultValue && valueObject == null)
			o[key] = "";
		else
			o[key] = valueObject;
	}
	else if (valueType == "xml")
	{
		o[key] = valueNode;
	}
	else if (valueType == "integer")
	{
		o[key] = parseInt(valueObject);
	}
	else if (valueType == "bool")
	{
		o[key] = new Boolean(valueObject);
	}
	else if (valuetype == "list")
	{
		var array = new Array();
		var str = valueObject;
		if (str.charAt(0) == "[")
			str = str.substr(1);
		if (str.charAt(str.length-1) == "]")
			str = str.substr(0, str.length-1);
		array = str.split(",");
		o[key] = array;
	}
}

/* 
   ESP class.
*/
function ESP()
{
	/* Tracking components */
	if ( ESP.__components == null )
	{
		ESP.__components = new Array();
	}
	/* Access GroupIds */
	if ( ESP.__accessGroupIds == null )
	{
		ESP.__accessGroupIds = new Array();
	}
}

/* 
   Function that content developer can set to return an array of
   SlideId strings that this slide has access to. Make sure to set
   this when the html file loads so the slide ids will be
   parsed correctly during sas export. Any ESP navigation calls
   to any slide ids not returned by this function will fail.
*//*
ESP.GetAccessSlideIds = function()
{
	return ["SlideID_A", "SlideID_B", "SlideID_C"];
}
*/

/*
   Function that content developer can set to return an array of
   GroupId strings that this slide has access to. Make sure to set
   this when the html file loads so the group ids will be
   parsed correctly during sas export. Any ESP navigation calls
   to any group ids not returned by this function will fail.
*//*
ESP.GetAccessGroupIds = function()
{
	return ["GroupID_A", "GroupID_B", "GroupID_C"];
}
*/

/*
   Function that content developer can set to return an array of
   Group Objects that pertain to this slide. Make sure to set
   this when the html file loads so the groups will be
   parsed correctly during sas export. Any ESP navigation calls
   to any groups not returned by this function will fail.
   The format of a group object is {GroupID:"GroupID", SlideIDs:["SlideId1", "SlideId2", ...]}
*//*
ESP.GetGroups = function()
{
	return [{GroupID:"GroupID", SlideIDs:["SlideId1", "SlideId2"]}];
}
*/

/* 
   Getter method to access the tracking components
*/
ESP.GetComponents = function()
{
	return ESP.__components;
}

/* 
   Method to register a tracking component
*/
ESP.RegisterComponent = function(comp)
{
	//alert("register component!");
	// If the component doesn't already exist in the array of tracking components
	if (!ESP.ComponentExists(comp))
	{
		// Add the component to the end of the components array
		ESP.__components.push(comp);
	}
}

/* 
   Returns true if the component exists in the array of registered components
*/
ESP.ComponentExists = function(comp)
{
	for(var i=0; i<ESP.__components.length; i++)
	{
		if (ESP.__components[i] == comp)
			return true;
	}
	return false;
}

/* 
   Returns an array of the group ids which this slide has access to
*/
ESP.GetGroupIds = function()
{
	// Create an empty array of group ids
	var grpIds = new Array();
	// Get any group ids returned by the access function
	var tmp = new Array();
	if ( typeof ESP.GetAccessGroupIds != "undefined" )
	{
		tmp = ESP.GetAccessGroupIds();
	}
	for (var i = 0; i < tmp.length; i++)
	{
		grpIds.push(tmp[i]);
	}
	// Make sure we have an empty array
	// Add any registered group ids that are not already in the array
	for (var i = 0; i < ESP.__accessGroupIds.length; i++)
	{
		var groupId = ESP.__accessGroupIds[i];
		// See if groupId doesn't exist
		var exists = false;
		for (var j = 0; j < grpIds.length; j++)
		{
			var id = grpIds[j];
			if (id == groupId)
			{
				exists = true;
				break;
			}
		}
		// If it doesn't exist then add it to the group ids
		if (!exists)
			grpIds.push(groupId);
	}
	return grpIds;
}
	
/* 
   Method to register access to a group id
*/
ESP.RegisterGroupId = function(groupId)
{
	// Add the group id to the end of the access group ids array
	ESP.__accessGroupIds.push(groupId);
}

// Create an instance of the ESP class so it will be initialized
esp = new ESP();