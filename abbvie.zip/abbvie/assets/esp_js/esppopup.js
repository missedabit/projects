/*
   ESPPopup.js 
   Author: MJR
   Version: 1.1
   Created: 05/12/2011
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESP Popup class.
   This class is used to make popup tracking calls from the content to the host ESP application.
*/

function ESPPopup(trackId, description)
{
	/* Private trackID variable */
	this.m_trackID = "POPUP";

	/* Private description variable */
	this.m_description = "";

	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}
	
/*
   All track items must have this property return true
*/
ESPPopup.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPPopup.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// Popup node
  	trackItemNode.appendChild( xmlDoc.createElement( "Popup" ) );
  	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPPopup.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPPopup.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Submits a popup event
	opened:		boolean indicating popup event
	
	returns:	True if submitted successfully, false not submitted.	
*/
ESPPopup.prototype.Submit = function(opened)
{		
	// Get the track xml to submit
	var xml = this.GetTrackXml( opened );
	
	//trace(xml);
	
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID, xml);
	
	// Return the callID so caller can identify it in myCallback
	return callID;
}

/*
   Returns the xml string to submit to the host ESP application for the track data.
	opened:		boolean popup event
	
	returns:	Xml string containing tracking data
*/
ESPPopup.prototype.GetTrackXml = function(opened)
{
	// Create the XML by hand for now
	var xml = "<Track><Opened>" + opened + "</Opened></Track>";
	return xml;
}

function Popup_Opened(p)
{
	//console.log("<<<<<<<<<<<<<<<<<<<< Popup_Opened >>>>>>>>>>>>>>>>>> ");
//	$.each( p, function( key, value ) {
	//	if(key=="m_trackID" || key=="m_description"){
	//		console.log( key + ": " + value );
	//	}
	//});
	if(p.clicked!=true){
		p.Submit(true);
	}
	p.clicked=true;
	
}

function Popup_Closed(p)
{
	p.Submit(false);
}

// Create an instance of the ESPPopup class so it will be initialized
esppopup = new ESPPopup();
