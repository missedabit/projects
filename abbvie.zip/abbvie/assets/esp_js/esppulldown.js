/*
   ESPPullDown.js 
   Author: MJR
   Version: 1.1
   Created: 05/12/2011
   Modified: 06/01/2011
   Copyright: ExploriaSPS, LLC.
	
   This javascript file holds the definition for the ESPPullDown class.
   This class is used to make survey tracking calls from the content to the host ESP application.
*/

/* 
   ESP PullDown class.
*/
function ESPPullDown(trackId, description, items)
{
	/* Private trackID variable */
	this.m_trackID = "PULLDOWN";

	/* Private description variable */
	this.m_description = "";
	
	/* Empty array of string items. */
	this.Items = [];
	
	// Set the data members based on the passed arguments
	this.SetTrackID( trackId );
	this.SetDescription( description );
	this.SetItems( items );
	
	// Register this component with ESP if it is not the class init instance below
	if ( typeof this.m_trackID != "undefined" )
		ESP.RegisterComponent(this);
}
	
/*
   All track items must have this property return true
*/
ESPPullDown.prototype.IsTrackItem = function()
{
	return true;
}

/*
   All track items must implement this function that returns an XMLNode
   representing the TrackItem node for the item that is being tracked.
*/
ESPPullDown.prototype.GetTrackItem = function()
{
	if ( window.DOMParser )
	{
		parser = new DOMParser();
		xmlDoc = parser.parseFromString("", "text/xml");	
	}
	else
	{
  		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
	}
  	var trackItemNode = xmlDoc.createElement( "TrackItem" );
  	// TrackID node
  	var trackIDNode = xmlDoc.createElement( "TrackID" );
  	trackIDNode.appendChild( xmlDoc.createTextNode( this.m_trackID ) );
  	trackItemNode.appendChild( trackIDNode );
  	// Static node
  	var staticNode = xmlDoc.createElement( "Static" );
  	var attr = xmlDoc.createAttribute( "isStatic" );
  	attr.nodeValue = "false";
  	staticNode.setAttributeNode( attr );
  	trackItemNode.appendChild( staticNode );
  	// Description node
  	var descriptionNode = xmlDoc.createElement( "Description" );
  	descriptionNode.appendChild( xmlDoc.createTextNode( this.m_description ) );
  	trackItemNode.appendChild( descriptionNode );
  	// PullDown node
   	var pulldownNode = xmlDoc.createElement( "PullDown" );
  	trackItemNode.appendChild( pulldownNode );
  	// Each PullDownItem node
  	for ( var i = 0; i < this.Items.length; i++ )
  	{
  		// PullDownItem node
  		var pulldownitemNode = xmlDoc.createElement( "PullDownItem" );
  		// PullDownItem text node
  		pulldownitemNode.appendChild( xmlDoc.createTextNode( this.Items[i] ) );
  		pulldownNode.appendChild( pulldownitemNode );
  	}

 	return trackItemNode;
}

/*
   Sets the trackId.
*/
ESPPullDown.prototype.SetTrackID = function(trackId)
{
	this.m_trackID = trackId;
}

/*
   Sets the description.
*/
ESPPullDown.prototype.SetDescription = function(description)
{
	this.m_description = description;
}

/*
   Sets the items.
*/
ESPPullDown.prototype.SetItems = function(items)
{
	if ( typeof items != "undefined" )
		this.Items = items;
}

/*
   Submits the PullDown text string
	itemIndex:	integer index of selected item
	
	returns:	CallID of CCAPI request, used to identify response in myCallback	
*/	
ESPPullDown.prototype.Submit = function(itemIndex)
{
	// Get the track xml to submit
	var xml = this.GetTrackXml( itemIndex );
	
	//trace(xml);
	
	var callID = CCAPI.CallESPFunction(CCAPI.TRK_set, "myCallback", this.m_trackID, xml);

	// Return the callID so caller can identify it in myCallback
	return callID;
}


/*
   Returns the xml string to submit to the host ESP application for the track data.
	itemIndex:	integer
	
	returns:	Xml string containing tracking data
*/
ESPPullDown.prototype.GetTrackXml = function(itemIndex)
{
	// Create the XML by hand for now
	var xml = "<Track><Items><Item>" + itemIndex + "</Item></Items></Track>"

	return xml;
}

function PullDown_Submit( p, itemIndex )
{
	p.Submit( itemIndex );
}

// Create an instance of the ESPPullDown class so it will be initialized
esppulldown = new ESPPullDown();
